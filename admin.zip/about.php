<?php
/**
 * SITUNEO DIGITAL - About Us Page
 * Company overview, mission/vision, values, team, dan company timeline
 */

require_once __DIR__ . '/includes/init.php';

// Page config
$currentPage = 'about';
$pageTitle = 'Tentang Kami';
$pageDescription = 'SITUNEO DIGITAL adalah perusahaan digital agency terpercaya dengan NIB resmi. Kami menyediakan solusi digital lengkap untuk bisnis Anda.';
$pageKeywords = 'tentang situneo, digital agency indonesia, web development company, about us';

// Include header
include __DIR__ . '/components/layout/header.php';
?>

<style>
/* About Page Styles */
.about-hero {
    background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%);
    padding: 120px 0 80px;
    position: relative;
    overflow: hidden;
}

.about-hero::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: url('data:image/svg+xml,<svg width="100" height="100" xmlns="http://www.w3.org/2000/svg"><rect width="100" height="100" fill="none" stroke="rgba(255,255,255,0.05)" stroke-width="1"/></svg>');
    background-size: 50px 50px;
}

.about-hero-content {
    position: relative;
    z-index: 2;
    color: white;
    text-align: center;
}

.about-hero h1 {
    font-size: 3rem;
    font-weight: 800;
    margin-bottom: 1.5rem;
    background: linear-gradient(135deg, #FFB400 0%, #FFD700 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.about-hero p {
    font-size: 1.25rem;
    color: rgba(255,255,255,0.9);
    max-width: 700px;
    margin: 0 auto;
}

/* Company Info */
.company-info {
    background: white;
    padding: 60px 0;
}

.info-card {
    background: white;
    border-radius: 16px;
    padding: 30px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    margin-bottom: 30px;
    border-left: 4px solid #FFB400;
    transition: transform 0.3s ease;
}

.info-card:hover {
    transform: translateY(-5px);
}

.info-card h3 {
    color: #1E5C99;
    font-size: 1.5rem;
    font-weight: 700;
    margin-bottom: 15px;
}

.info-card .info-item {
    display: flex;
    align-items: flex-start;
    margin-bottom: 12px;
}

.info-card .info-item i {
    color: #FFB400;
    margin-right: 12px;
    margin-top: 4px;
    font-size: 1.1rem;
}

.info-card .info-item span {
    color: #555;
    line-height: 1.6;
}

/* Mission Vision */
.mission-vision {
    background: #f8f9fa;
    padding: 80px 0;
}

.mv-card {
    background: white;
    border-radius: 20px;
    padding: 40px;
    text-align: center;
    box-shadow: 0 4px 30px rgba(0,0,0,0.08);
    height: 100%;
    transition: all 0.3s ease;
}

.mv-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 8px 40px rgba(0,0,0,0.12);
}

.mv-icon {
    width: 80px;
    height: 80px;
    background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 30px;
}

.mv-icon i {
    font-size: 2.5rem;
    color: #FFD700;
}

.mv-card h3 {
    color: #1E5C99;
    font-size: 1.8rem;
    font-weight: 700;
    margin-bottom: 20px;
}

.mv-card p {
    color: #666;
    line-height: 1.8;
    font-size: 1.05rem;
}

/* Values */
.values-section {
    padding: 80px 0;
    background: white;
}

.value-item {
    text-align: center;
    margin-bottom: 40px;
}

.value-icon {
    width: 100px;
    height: 100px;
    background: linear-gradient(135deg, #FFB400 0%, #FFD700 100%);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 25px;
    transition: all 0.3s ease;
}

.value-item:hover .value-icon {
    transform: scale(1.1) rotate(5deg);
    box-shadow: 0 10px 30px rgba(255, 180, 0, 0.3);
}

.value-icon i {
    font-size: 3rem;
    color: white;
}

.value-item h4 {
    color: #1E5C99;
    font-size: 1.4rem;
    font-weight: 700;
    margin-bottom: 15px;
}

.value-item p {
    color: #666;
    line-height: 1.7;
}

/* Timeline */
.timeline-section {
    background: #f8f9fa;
    padding: 80px 0;
}

.timeline {
    position: relative;
    max-width: 900px;
    margin: 0 auto;
    padding: 40px 0;
}

.timeline::before {
    content: '';
    position: absolute;
    left: 50%;
    transform: translateX(-50%);
    width: 4px;
    height: 100%;
    background: linear-gradient(180deg, #1E5C99 0%, #FFB400 100%);
}

.timeline-item {
    display: flex;
    margin-bottom: 50px;
    position: relative;
}

.timeline-item:nth-child(odd) {
    flex-direction: row-reverse;
}

.timeline-content {
    width: 45%;
    background: white;
    padding: 30px;
    border-radius: 16px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    position: relative;
}

.timeline-item:nth-child(odd) .timeline-content {
    text-align: right;
}

.timeline-year {
    position: absolute;
    left: 50%;
    transform: translateX(-50%);
    background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%);
    color: white;
    padding: 12px 24px;
    border-radius: 30px;
    font-weight: 700;
    font-size: 1.1rem;
    box-shadow: 0 4px 15px rgba(30, 92, 153, 0.3);
    z-index: 2;
}

.timeline-content h4 {
    color: #1E5C99;
    font-size: 1.3rem;
    font-weight: 700;
    margin-bottom: 10px;
}

.timeline-content p {
    color: #666;
    line-height: 1.7;
}

/* CTA Section */
.about-cta {
    background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%);
    padding: 80px 0;
    text-align: center;
    color: white;
}

.about-cta h2 {
    font-size: 2.5rem;
    font-weight: 800;
    margin-bottom: 20px;
}

.about-cta p {
    font-size: 1.2rem;
    margin-bottom: 40px;
    opacity: 0.9;
}

/* Responsive */
@media (max-width: 768px) {
    .about-hero h1 {
        font-size: 2rem;
    }
    
    .about-hero p {
        font-size: 1rem;
    }
    
    .timeline::before {
        left: 30px;
    }
    
    .timeline-item {
        flex-direction: column !important;
        padding-left: 60px;
    }
    
    .timeline-content {
        width: 100%;
        text-align: left !important;
    }
    
    .timeline-year {
        left: 30px;
        transform: translateX(-50%);
    }
}
</style>

<!-- Hero Section -->
<section class="about-hero">
    <div class="container">
        <div class="about-hero-content">
            <h1>Tentang SITUNEO DIGITAL</h1>
            <p>
                Perusahaan digital agency terpercaya dengan NIB resmi yang berkomitmen 
                memberikan solusi digital terbaik untuk mengembangkan bisnis Anda
            </p>
        </div>
    </div>
</section>

<!-- Company Info -->
<section class="company-info">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="info-card">
                    <h3><i class="fas fa-building"></i> Informasi Perusahaan</h3>
                    <div class="info-item">
                        <i class="fas fa-certificate"></i>
                        <span><strong>NIB:</strong> <?php echo COMPANY_NIB; ?></span>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-id-card"></i>
                        <span><strong>NPWP:</strong> <?php echo COMPANY_NPWP; ?></span>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-user-tie"></i>
                        <span><strong>Direktur:</strong> <?php echo COMPANY_DIRECTOR; ?></span>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-calendar-alt"></i>
                        <span><strong>Berdiri:</strong> 2020</span>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="info-card">
                    <h3><i class="fas fa-map-marker-alt"></i> Kontak & Lokasi</h3>
                    <div class="info-item">
                        <i class="fas fa-envelope"></i>
                        <span><strong>Email:</strong> <?php echo ADMIN_EMAIL; ?></span>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-phone"></i>
                        <span><strong>Phone:</strong> <?php echo COMPANY_PHONE; ?></span>
                    </div>
                    <div class="info-item">
                        <i class="fab fa-whatsapp"></i>
                        <span><strong>WhatsApp:</strong> <?php echo WHATSAPP_NUMBER; ?></span>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-globe"></i>
                        <span><strong>Website:</strong> <?php echo SITE_URL; ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Mission & Vision -->
<section class="mission-vision">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">Misi & Visi Kami</h2>
            <p class="section-subtitle text-muted">Komitmen kami untuk memberikan yang terbaik</p>
        </div>
        
        <div class="row">
            <div class="col-md-6 mb-4">
                <div class="mv-card">
                    <div class="mv-icon">
                        <i class="fas fa-bullseye"></i>
                    </div>
                    <h3>Misi Kami</h3>
                    <p>
                        Memberikan solusi digital berkualitas tinggi yang terjangkau untuk semua 
                        kalangan bisnis. Kami berkomitmen membantu UMKM dan startup untuk go digital 
                        dengan biaya terjangkau mulai dari Rp 150.000/bulan, tanpa mengorbankan 
                        kualitas dan profesionalisme.
                    </p>
                </div>
            </div>
            
            <div class="col-md-6 mb-4">
                <div class="mv-card">
                    <div class="mv-icon">
                        <i class="fas fa-eye"></i>
                    </div>
                    <h3>Visi Kami</h3>
                    <p>
                        Menjadi digital agency pilihan utama di Indonesia yang dikenal dengan 
                        harga terjangkau, kualitas premium, dan layanan after-sales terbaik. 
                        Kami ingin membantu 10,000+ bisnis untuk berkembang melalui transformasi 
                        digital pada tahun 2030.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Core Values -->
<section class="values-section">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">Nilai-Nilai Kami</h2>
            <p class="section-subtitle text-muted">Prinsip yang kami pegang teguh dalam setiap project</p>
        </div>
        
        <div class="row">
            <div class="col-md-3 col-sm-6">
                <div class="value-item">
                    <div class="value-icon">
                        <i class="fas fa-trophy"></i>
                    </div>
                    <h4>Kualitas Premium</h4>
                    <p>Setiap project dikerjakan dengan standar profesional tinggi</p>
                </div>
            </div>
            
            <div class="col-md-3 col-sm-6">
                <div class="value-item">
                    <div class="value-icon">
                        <i class="fas fa-hand-holding-usd"></i>
                    </div>
                    <h4>Harga Terjangkau</h4>
                    <p>Solusi digital berkualitas dengan harga yang ramah kantong</p>
                </div>
            </div>
            
            <div class="col-md-3 col-sm-6">
                <div class="value-item">
                    <div class="value-icon">
                        <i class="fas fa-headset"></i>
                    </div>
                    <h4>Support 24/7</h4>
                    <p>Tim support kami siap membantu Anda kapan saja</p>
                </div>
            </div>
            
            <div class="col-md-3 col-sm-6">
                <div class="value-item">
                    <div class="value-icon">
                        <i class="fas fa-rocket"></i>
                    </div>
                    <h4>Fast Delivery</h4>
                    <p>Project selesai tepat waktu, bahkan lebih cepat</p>
                </div>
            </div>
            
            <div class="col-md-3 col-sm-6">
                <div class="value-item">
                    <div class="value-icon">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <h4>Garansi Aman</h4>
                    <p>100% garansi uang kembali jika tidak puas</p>
                </div>
            </div>
            
            <div class="col-md-3 col-sm-6">
                <div class="value-item">
                    <div class="value-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <h4>Tim Profesional</h4>
                    <p>Dikerjakan oleh tim ahli berpengalaman</p>
                </div>
            </div>
            
            <div class="col-md-3 col-sm-6">
                <div class="value-item">
                    <div class="value-icon">
                        <i class="fas fa-lightbulb"></i>
                    </div>
                    <h4>Inovasi</h4>
                    <p>Selalu menggunakan teknologi terkini</p>
                </div>
            </div>
            
            <div class="col-md-3 col-sm-6">
                <div class="value-item">
                    <div class="value-icon">
                        <i class="fas fa-heart"></i>
                    </div>
                    <h4>Customer First</h4>
                    <p>Kepuasan client adalah prioritas utama kami</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Timeline -->
<section class="timeline-section">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">Perjalanan Kami</h2>
            <p class="section-subtitle text-muted">Milestone penting dalam perkembangan SITUNEO DIGITAL</p>
        </div>
        
        <div class="timeline">
            <div class="timeline-item">
                <div class="timeline-year">2020</div>
                <div class="timeline-content">
                    <h4>Berdirinya SITUNEO DIGITAL</h4>
                    <p>
                        Dimulai dengan visi untuk membantu UMKM go digital dengan harga terjangkau. 
                        Project pertama adalah website toko online untuk UMKM lokal.
                    </p>
                </div>
            </div>
            
            <div class="timeline-item">
                <div class="timeline-year">2021</div>
                <div class="timeline-content">
                    <h4>100+ Client Bergabung</h4>
                    <p>
                        Mencapai milestone 100+ client aktif dari berbagai industri. 
                        Meluncurkan paket subscription bulanan mulai dari Rp 150.000.
                    </p>
                </div>
            </div>
            
            <div class="timeline-item">
                <div class="timeline-year">2022</div>
                <div class="timeline-content">
                    <h4>Ekspansi Layanan</h4>
                    <p>
                        Menambah layanan mobile app development, digital marketing, dan SEO. 
                        Tim berkembang menjadi 15+ profesional.
                    </p>
                </div>
            </div>
            
            <div class="timeline-item">
                <div class="timeline-year">2023</div>
                <div class="timeline-content">
                    <h4>Penghargaan & Sertifikasi</h4>
                    <p>
                        Mendapat penghargaan "Best Digital Agency for UMKM". 
                        Resmi terdaftar dengan NIB dan NPWP.
                    </p>
                </div>
            </div>
            
            <div class="timeline-item">
                <div class="timeline-year">2024</div>
                <div class="timeline-content">
                    <h4>500+ Project Selesai</h4>
                    <p>
                        Menyelesaikan 500+ project dengan rating kepuasan 4.9/5.0. 
                        Meluncurkan program freelance partnership dengan tier system.
                    </p>
                </div>
            </div>
            
            <div class="timeline-item">
                <div class="timeline-year">2025</div>
                <div class="timeline-content">
                    <h4>Going National</h4>
                    <p>
                        Client dari seluruh Indonesia. Target: 1000+ client dan 
                        membantu lebih banyak UMKM untuk transformasi digital.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="about-cta">
    <div class="container">
        <h2>Siap Bergabung Dengan Kami?</h2>
        <p>Mari wujudkan transformasi digital bisnis Anda bersama SITUNEO DIGITAL</p>
        <div class="d-flex justify-content-center gap-3 flex-wrap">
            <a href="/services.php" class="btn btn-gold btn-lg">
                <i class="fas fa-briefcase"></i> Lihat Layanan Kami
            </a>
            <a href="<?php echo whatsappUrl('Halo! Saya tertarik untuk konsultasi tentang layanan SITUNEO DIGITAL'); ?>" 
               class="btn btn-outline-white btn-lg" target="_blank">
                <i class="fab fa-whatsapp"></i> Konsultasi Gratis
            </a>
        </div>
    </div>
</section>

<?php include __DIR__ . '/components/layout/footer.php'; ?>

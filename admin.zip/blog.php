<?php
/**
 * SITUNEO DIGITAL - Blog Page
 * Blog listing dengan search, category filters, dan pagination
 */

require_once __DIR__ . '/includes/init.php';

// Page config
$currentPage = 'blog';
$pageTitle = 'Blog & Artikel';
$pageDescription = 'Baca artikel terbaru seputar web development, digital marketing, SEO, dan tips bisnis digital dari SITUNEO DIGITAL.';
$pageKeywords = 'blog, artikel, tutorial, tips website, digital marketing tips';

// Get filters
$categoryId = isset($_GET['category']) ? (int)$_GET['category'] : 0;
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$perPage = 9;

// Build query
$query = "SELECT bp.*, bc.name as category_name, bc.slug as category_slug 
          FROM blog_posts bp 
          LEFT JOIN blog_categories bc ON bp.category_id = bc.id 
          WHERE bp.status = 'published'";

$params = [];

if ($categoryId > 0) {
    $query .= " AND bp.category_id = ?";
    $params[] = $categoryId;
}

if (!empty($search)) {
    $query .= " AND (bp.title LIKE ? OR bp.content LIKE ? OR bp.excerpt LIKE ?)";
    $searchTerm = "%{$search}%";
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
}

$query .= " ORDER BY bp.published_at DESC";

// Get posts
$posts = $db->fetchAll($query, $params);

// Get categories
$categories = $db->fetchAll("SELECT * FROM blog_categories WHERE is_active = 1 ORDER BY name ASC");

// Get recent posts for sidebar
$recentPosts = $db->fetchAll("SELECT * FROM blog_posts WHERE status = 'published' ORDER BY published_at DESC LIMIT 5");

// Get popular tags
$popularTags = $db->fetchAll("
    SELECT tags, COUNT(*) as count 
    FROM blog_posts 
    WHERE status = 'published' AND tags IS NOT NULL AND tags != ''
    GROUP BY tags 
    ORDER BY count DESC 
    LIMIT 10
");

// Include header
include __DIR__ . '/components/layout/header.php';
?>

<style>
/* Blog Page Styles */
.blog-header {
    background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%);
    padding: 100px 0 60px;
    position: relative;
    overflow: hidden;
}

.blog-header::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: url('data:image/svg+xml,<svg width="60" height="60" xmlns="http://www.w3.org/2000/svg"><rect width="60" height="60" fill="none" stroke="rgba(255,255,255,0.03)" stroke-width="1"/></svg>');
    background-size: 60px 60px;
}

.blog-header-content {
    position: relative;
    z-index: 2;
    text-align: center;
    color: white;
}

.blog-header h1 {
    font-size: 2.8rem;
    font-weight: 800;
    margin-bottom: 1rem;
    background: linear-gradient(135deg, #FFB400 0%, #FFD700 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.blog-header p {
    font-size: 1.2rem;
    opacity: 0.9;
}

/* Search & Filters */
.blog-filters {
    background: white;
    padding: 30px 0;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    position: sticky;
    top: 0;
    z-index: 100;
}

.search-box {
    position: relative;
    max-width: 600px;
    margin: 0 auto 20px;
}

.search-box input {
    width: 100%;
    padding: 15px 50px 15px 20px;
    border: 2px solid #e0e0e0;
    border-radius: 50px;
    font-size: 1rem;
    transition: all 0.3s ease;
}

.search-box input:focus {
    border-color: #1E5C99;
    outline: none;
    box-shadow: 0 0 0 4px rgba(30, 92, 153, 0.1);
}

.search-box button {
    position: absolute;
    right: 5px;
    top: 50%;
    transform: translateY(-50%);
    background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%);
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 50px;
    cursor: pointer;
    transition: all 0.3s ease;
}

.search-box button:hover {
    background: linear-gradient(135deg, #0F3057 0%, #1E5C99 100%);
}

.category-filters {
    display: flex;
    justify-content: center;
    gap: 10px;
    flex-wrap: wrap;
}

.filter-btn {
    padding: 10px 20px;
    border: 2px solid #e0e0e0;
    background: white;
    border-radius: 50px;
    cursor: pointer;
    transition: all 0.3s ease;
    font-weight: 600;
    color: #666;
    text-decoration: none;
}

.filter-btn:hover, .filter-btn.active {
    background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%);
    color: white;
    border-color: #1E5C99;
}

/* Blog Container */
.blog-container {
    padding: 60px 0;
}

/* Blog Card */
.blog-card {
    background: white;
    border-radius: 20px;
    overflow: hidden;
    box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    transition: all 0.3s ease;
    margin-bottom: 30px;
    height: 100%;
    display: flex;
    flex-direction: column;
}

.blog-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 12px 40px rgba(0,0,0,0.15);
}

.blog-image {
    position: relative;
    padding-top: 60%;
    overflow: hidden;
}

.blog-image img {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.5s ease;
}

.blog-card:hover .blog-image img {
    transform: scale(1.1);
}

.blog-category {
    position: absolute;
    top: 15px;
    left: 15px;
    background: linear-gradient(135deg, #FFB400 0%, #FFD700 100%);
    color: white;
    padding: 6px 16px;
    border-radius: 50px;
    font-size: 0.85rem;
    font-weight: 600;
}

.blog-content {
    padding: 25px;
    flex-grow: 1;
    display: flex;
    flex-direction: column;
}

.blog-meta {
    display: flex;
    gap: 15px;
    margin-bottom: 15px;
    color: #999;
    font-size: 0.9rem;
}

.blog-meta i {
    color: #FFB400;
}

.blog-title {
    color: #1E5C99;
    font-size: 1.4rem;
    font-weight: 700;
    margin-bottom: 12px;
    line-height: 1.4;
}

.blog-title a {
    color: #1E5C99;
    text-decoration: none;
    transition: color 0.3s ease;
}

.blog-title a:hover {
    color: #FFB400;
}

.blog-excerpt {
    color: #666;
    line-height: 1.7;
    margin-bottom: 20px;
    flex-grow: 1;
}

.blog-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-top: 20px;
    border-top: 1px solid #e0e0e0;
}

.blog-author {
    display: flex;
    align-items: center;
    gap: 10px;
}

.author-avatar {
    width: 35px;
    height: 35px;
    border-radius: 50%;
    background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: 700;
}

.author-name {
    color: #666;
    font-size: 0.9rem;
}

.read-more {
    color: #1E5C99;
    text-decoration: none;
    font-weight: 600;
    transition: color 0.3s ease;
}

.read-more:hover {
    color: #FFB400;
}

/* Sidebar */
.blog-sidebar {
    position: sticky;
    top: 100px;
}

.sidebar-widget {
    background: white;
    border-radius: 20px;
    padding: 30px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    margin-bottom: 30px;
}

.sidebar-widget h3 {
    color: #1E5C99;
    font-size: 1.3rem;
    font-weight: 700;
    margin-bottom: 20px;
    padding-bottom: 15px;
    border-bottom: 2px solid #f0f0f0;
}

.recent-post-item {
    display: flex;
    gap: 15px;
    margin-bottom: 20px;
    padding-bottom: 20px;
    border-bottom: 1px solid #f0f0f0;
}

.recent-post-item:last-child {
    margin-bottom: 0;
    padding-bottom: 0;
    border-bottom: none;
}

.recent-post-thumb {
    width: 80px;
    height: 80px;
    border-radius: 12px;
    overflow: hidden;
    flex-shrink: 0;
}

.recent-post-thumb img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.recent-post-info h4 {
    font-size: 0.95rem;
    font-weight: 600;
    margin-bottom: 5px;
}

.recent-post-info h4 a {
    color: #333;
    text-decoration: none;
    transition: color 0.3s ease;
}

.recent-post-info h4 a:hover {
    color: #FFB400;
}

.recent-post-date {
    color: #999;
    font-size: 0.85rem;
}

.tag-cloud {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
}

.tag {
    background: #f8f9fa;
    color: #666;
    padding: 8px 16px;
    border-radius: 20px;
    font-size: 0.9rem;
    text-decoration: none;
    transition: all 0.3s ease;
}

.tag:hover {
    background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%);
    color: white;
}

/* Empty State */
.empty-state {
    text-align: center;
    padding: 80px 20px;
}

.empty-state i {
    font-size: 5rem;
    color: #ddd;
    margin-bottom: 20px;
}

.empty-state h3 {
    color: #666;
    margin-bottom: 10px;
}

.empty-state p {
    color: #999;
}

/* Pagination */
.pagination {
    display: flex;
    justify-content: center;
    gap: 10px;
    margin-top: 40px;
}

.pagination a, .pagination span {
    padding: 10px 18px;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    color: #666;
    text-decoration: none;
    transition: all 0.3s ease;
}

.pagination a:hover, .pagination span.active {
    background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%);
    color: white;
    border-color: #1E5C99;
}

/* Responsive */
@media (max-width: 768px) {
    .blog-header h1 {
        font-size: 2rem;
    }
    
    .category-filters {
        gap: 5px;
    }
    
    .filter-btn {
        padding: 8px 15px;
        font-size: 0.9rem;
    }
    
    .blog-sidebar {
        position: relative;
        top: 0;
        margin-top: 40px;
    }
}
</style>

<!-- Header Section -->
<section class="blog-header">
    <div class="container">
        <div class="blog-header-content">
            <h1>Blog & Artikel</h1>
            <p>Tips, tutorial, dan insight seputar digital business</p>
        </div>
    </div>
</section>

<!-- Filters Section -->
<section class="blog-filters">
    <div class="container">
        <!-- Search Box -->
        <form method="GET" action="/blog.php" class="search-box">
            <input type="text" 
                   name="search" 
                   placeholder="Cari artikel..." 
                   value="<?php echo htmlspecialchars($search); ?>">
            <button type="submit">
                <i class="fas fa-search"></i>
            </button>
        </form>
        
        <!-- Category Filters -->
        <div class="category-filters">
            <a href="/blog.php" class="filter-btn <?php echo $categoryId === 0 ? 'active' : ''; ?>">
                Semua Artikel
            </a>
            <?php foreach ($categories as $cat): ?>
                <a href="/blog.php?category=<?php echo $cat['id']; ?>" 
                   class="filter-btn <?php echo $categoryId === $cat['id'] ? 'active' : ''; ?>">
                    <?php echo htmlspecialchars($cat['name']); ?>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Blog Container -->
<section class="blog-container">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <?php if (empty($posts)): ?>
                    <!-- Empty State -->
                    <div class="empty-state">
                        <i class="fas fa-search"></i>
                        <h3>Tidak Ada Artikel Ditemukan</h3>
                        <p>Coba gunakan kata kunci lain atau filter berbeda</p>
                        <a href="/blog.php" class="btn btn-primary mt-3">
                            <i class="fas fa-arrow-left"></i> Kembali ke Semua Artikel
                        </a>
                    </div>
                <?php else: ?>
                    <div class="row">
                        <?php foreach ($posts as $post): ?>
                            <?php
                            $imageUrl = !empty($post['featured_image']) 
                                ? $post['featured_image'] 
                                : 'https://source.unsplash.com/800x600/?' . urlencode($post['title']);
                            
                            $authorInitial = strtoupper(substr($post['author'] ?? 'A', 0, 1));
                            ?>
                            
                            <div class="col-md-6 mb-4">
                                <div class="blog-card">
                                    <div class="blog-image">
                                        <img src="<?php echo $imageUrl; ?>" 
                                             alt="<?php echo htmlspecialchars($post['title']); ?>">
                                        <span class="blog-category">
                                            <?php echo htmlspecialchars($post['category_name'] ?? 'Artikel'); ?>
                                        </span>
                                    </div>
                                    
                                    <div class="blog-content">
                                        <div class="blog-meta">
                                            <span>
                                                <i class="far fa-calendar"></i>
                                                <?php echo formatDate($post['published_at']); ?>
                                            </span>
                                            <span>
                                                <i class="far fa-clock"></i>
                                                <?php echo $post['read_time'] ?? '5'; ?> min baca
                                            </span>
                                        </div>
                                        
                                        <h3 class="blog-title">
                                            <a href="/blog/<?php echo $post['slug']; ?>">
                                                <?php echo htmlspecialchars($post['title']); ?>
                                            </a>
                                        </h3>
                                        
                                        <p class="blog-excerpt">
                                            <?php echo htmlspecialchars(substr($post['excerpt'] ?? $post['content'], 0, 150)) . '...'; ?>
                                        </p>
                                        
                                        <div class="blog-footer">
                                            <div class="blog-author">
                                                <div class="author-avatar"><?php echo $authorInitial; ?></div>
                                                <span class="author-name"><?php echo htmlspecialchars($post['author'] ?? 'Admin'); ?></span>
                                            </div>
                                            <a href="/blog/<?php echo $post['slug']; ?>" class="read-more">
                                                Baca Selengkapnya <i class="fas fa-arrow-right"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- Pagination (simple example) -->
                    <?php if (count($posts) >= $perPage): ?>
                        <div class="pagination">
                            <?php if ($page > 1): ?>
                                <a href="?page=<?php echo $page - 1; ?><?php echo $categoryId > 0 ? '&category=' . $categoryId : ''; ?>">
                                    <i class="fas fa-chevron-left"></i>
                                </a>
                            <?php endif; ?>
                            
                            <span class="active"><?php echo $page; ?></span>
                            
                            <a href="?page=<?php echo $page + 1; ?><?php echo $categoryId > 0 ? '&category=' . $categoryId : ''; ?>">
                                <i class="fas fa-chevron-right"></i>
                            </a>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            
            <!-- Sidebar -->
            <div class="col-lg-4">
                <div class="blog-sidebar">
                    <!-- Recent Posts Widget -->
                    <?php if (!empty($recentPosts)): ?>
                        <div class="sidebar-widget">
                            <h3>Artikel Terbaru</h3>
                            <?php foreach ($recentPosts as $recent): ?>
                                <?php
                                $recentImage = !empty($recent['featured_image']) 
                                    ? $recent['featured_image'] 
                                    : 'https://source.unsplash.com/200x200/?' . urlencode($recent['title']);
                                ?>
                                <div class="recent-post-item">
                                    <div class="recent-post-thumb">
                                        <img src="<?php echo $recentImage; ?>" alt="<?php echo htmlspecialchars($recent['title']); ?>">
                                    </div>
                                    <div class="recent-post-info">
                                        <h4>
                                            <a href="/blog/<?php echo $recent['slug']; ?>">
                                                <?php echo htmlspecialchars(substr($recent['title'], 0, 60)) . '...'; ?>
                                            </a>
                                        </h4>
                                        <div class="recent-post-date">
                                            <?php echo formatRelativeTime($recent['published_at']); ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    
                    <!-- Categories Widget -->
                    <div class="sidebar-widget">
                        <h3>Kategori</h3>
                        <div class="tag-cloud">
                            <?php foreach ($categories as $cat): ?>
                                <a href="/blog.php?category=<?php echo $cat['id']; ?>" class="tag">
                                    <?php echo htmlspecialchars($cat['name']); ?>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    
                    <!-- Newsletter Widget -->
                    <div class="sidebar-widget" style="background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%); color: white;">
                        <h3 style="color: #FFD700; border-color: rgba(255,255,255,0.2);">Newsletter</h3>
                        <p style="color: rgba(255,255,255,0.9); margin-bottom: 20px;">
                            Dapatkan artikel terbaru langsung di inbox Anda
                        </p>
                        <form style="display: flex; flex-direction: column; gap: 10px;">
                            <input type="email" 
                                   placeholder="Email Anda" 
                                   style="padding: 12px; border: none; border-radius: 8px;">
                            <button type="submit" 
                                    style="padding: 12px; background: linear-gradient(135deg, #FFB400 0%, #FFD700 100%); color: white; border: none; border-radius: 8px; font-weight: 700; cursor: pointer;">
                                Subscribe
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="section bg-gradient-primary text-white text-center">
    <div class="container">
        <h2 class="mb-3">Punya Pertanyaan?</h2>
        <p class="mb-4">Hubungi kami untuk konsultasi gratis seputar digital marketing dan web development</p>
        <a href="<?php echo whatsappUrl('Halo! Saya punya pertanyaan seputar digital marketing'); ?>" 
           class="btn btn-gold btn-lg" target="_blank">
            <i class="fab fa-whatsapp"></i> Chat Sekarang
        </a>
    </div>
</section>

<?php include __DIR__ . '/components/layout/footer.php'; ?>

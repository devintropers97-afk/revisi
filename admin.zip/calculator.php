<?php
/**
 * SITUNEO DIGITAL - Price Calculator
 * Interactive price calculator dengan real-time calculation
 */

require_once __DIR__ . '/includes/init.php';

// Page config
$currentPage = 'calculator';
$pageTitle = 'Kalkulator Harga';
$pageDescription = 'Hitung biaya project digital Anda secara real-time. Pilih layanan, paket, dan add-ons sesuai kebutuhan.';
$pageKeywords = 'kalkulator harga, price calculator, estimasi biaya website';

// Get services with packages
$services = $db->fetchAll("
    SELECT s.*, sc.name as category_name 
    FROM services s 
    LEFT JOIN service_categories sc ON s.category_id = sc.id 
    WHERE s.is_active = 1 
    ORDER BY s.order_position ASC, s.name ASC
");

// Get all service categories
$categories = getServiceCategories();

// Include header
include __DIR__ . '/components/layout/header.php';
?>

<style>
/* Calculator Page Styles */
.calculator-header {
    background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%);
    padding: 100px 0 60px;
    position: relative;
    overflow: hidden;
}

.calculator-header::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: url('data:image/svg+xml,<svg width="100" height="100" xmlns="http://www.w3.org/2000/svg"><rect width="100" height="100" fill="none" stroke="rgba(255,255,255,0.03)" stroke-width="1"/></svg>');
    background-size: 100px 100px;
}

.calculator-header-content {
    position: relative;
    z-index: 2;
    text-align: center;
    color: white;
}

.calculator-header h1 {
    font-size: 2.8rem;
    font-weight: 800;
    margin-bottom: 1rem;
    background: linear-gradient(135deg, #FFB400 0%, #FFD700 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.calculator-header p {
    font-size: 1.2rem;
    opacity: 0.9;
}

/* Calculator Container */
.calculator-container {
    padding: 60px 0;
}

.calculator-form {
    background: white;
    border-radius: 24px;
    padding: 40px;
    box-shadow: 0 4px 30px rgba(0,0,0,0.08);
    margin-bottom: 30px;
}

.form-section {
    margin-bottom: 35px;
    padding-bottom: 35px;
    border-bottom: 2px solid #f0f0f0;
}

.form-section:last-child {
    border-bottom: none;
    margin-bottom: 0;
    padding-bottom: 0;
}

.section-title {
    color: #1E5C99;
    font-size: 1.5rem;
    font-weight: 700;
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 12px;
}

.section-title i {
    color: #FFB400;
}

.section-subtitle {
    color: #999;
    font-size: 0.95rem;
    margin-bottom: 20px;
}

/* Service Selection */
.service-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    gap: 15px;
}

.service-option {
    position: relative;
}

.service-option input[type="checkbox"] {
    display: none;
}

.service-label {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 20px;
    border: 2px solid #e0e0e0;
    border-radius: 16px;
    cursor: pointer;
    transition: all 0.3s ease;
    background: white;
    text-align: center;
}

.service-option input:checked + .service-label {
    border-color: #1E5C99;
    background: linear-gradient(135deg, rgba(30, 92, 153, 0.05) 0%, rgba(15, 48, 87, 0.05) 100%);
}

.service-icon {
    font-size: 2rem;
    color: #1E5C99;
    margin-bottom: 10px;
}

.service-name {
    font-weight: 600;
    color: #333;
    margin-bottom: 5px;
}

.service-price {
    color: #FFB400;
    font-size: 0.9rem;
    font-weight: 700;
}

/* Package Selection */
.package-selector {
    display: none;
    margin-top: 20px;
    padding: 20px;
    background: #f8f9fa;
    border-radius: 16px;
}

.package-selector.active {
    display: block;
    animation: slideDown 0.3s ease;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.package-options {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 15px;
}

.package-option input[type="radio"] {
    display: none;
}

.package-label {
    display: block;
    padding: 15px;
    border: 2px solid #e0e0e0;
    border-radius: 12px;
    cursor: pointer;
    transition: all 0.3s ease;
    background: white;
    text-align: center;
}

.package-option input:checked + .package-label {
    border-color: #FFB400;
    background: linear-gradient(135deg, rgba(255, 180, 0, 0.1) 0%, rgba(255, 215, 0, 0.1) 100%);
}

.package-name {
    font-weight: 700;
    color: #1E5C99;
    margin-bottom: 5px;
}

.package-price {
    color: #FFB400;
    font-size: 1.1rem;
    font-weight: 700;
}

/* Add-ons */
.addon-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 15px;
}

.addon-item {
    display: flex;
    align-items: center;
    padding: 15px;
    border: 2px solid #e0e0e0;
    border-radius: 12px;
    cursor: pointer;
    transition: all 0.3s ease;
}

.addon-item:hover {
    border-color: #FFB400;
    background: #f8f9fa;
}

.addon-item input[type="checkbox"] {
    margin-right: 15px;
    width: 20px;
    height: 20px;
    cursor: pointer;
}

.addon-info {
    flex: 1;
}

.addon-name {
    font-weight: 600;
    color: #333;
    margin-bottom: 3px;
}

.addon-desc {
    font-size: 0.85rem;
    color: #999;
}

.addon-price {
    color: #FFB400;
    font-weight: 700;
    font-size: 1.1rem;
}

/* Quantity Input */
.quantity-control {
    display: flex;
    align-items: center;
    gap: 15px;
    background: #f8f9fa;
    padding: 15px 20px;
    border-radius: 12px;
}

.quantity-label {
    font-weight: 600;
    color: #333;
}

.quantity-input {
    display: flex;
    align-items: center;
    gap: 10px;
}

.quantity-btn {
    width: 40px;
    height: 40px;
    border: none;
    background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%);
    color: white;
    border-radius: 8px;
    font-size: 1.2rem;
    cursor: pointer;
    transition: all 0.3s ease;
}

.quantity-btn:hover {
    transform: scale(1.1);
}

.quantity-value {
    width: 60px;
    text-align: center;
    font-size: 1.2rem;
    font-weight: 700;
    color: #1E5C99;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    padding: 8px;
}

/* Summary Box */
.summary-box {
    background: white;
    border-radius: 24px;
    padding: 30px;
    box-shadow: 0 4px 30px rgba(0,0,0,0.08);
    position: sticky;
    top: 20px;
}

.summary-title {
    color: #1E5C99;
    font-size: 1.5rem;
    font-weight: 800;
    margin-bottom: 25px;
    text-align: center;
}

.summary-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 0;
    border-bottom: 1px solid #f0f0f0;
}

.summary-item:last-child {
    border-bottom: none;
}

.summary-label {
    color: #666;
    font-size: 0.95rem;
}

.summary-value {
    font-weight: 700;
    color: #1E5C99;
}

.summary-discount {
    background: linear-gradient(135deg, #FFB400 0%, #FFD700 100%);
    color: white;
    padding: 12px;
    border-radius: 12px;
    margin: 15px 0;
    text-align: center;
}

.summary-discount-label {
    font-size: 0.9rem;
    opacity: 0.9;
}

.summary-discount-value {
    font-size: 1.3rem;
    font-weight: 800;
}

.summary-total {
    background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%);
    color: white;
    padding: 20px;
    border-radius: 16px;
    margin: 20px 0;
    text-align: center;
}

.summary-total-label {
    font-size: 1rem;
    opacity: 0.9;
    margin-bottom: 5px;
}

.summary-total-value {
    font-size: 2.5rem;
    font-weight: 900;
}

.summary-cta {
    width: 100%;
    padding: 16px;
    background: linear-gradient(135deg, #FFB400 0%, #FFD700 100%);
    color: white;
    border: none;
    border-radius: 50px;
    font-weight: 700;
    font-size: 1.1rem;
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
    display: block;
    text-align: center;
}

.summary-cta:hover {
    background: linear-gradient(135deg, #FFD700 0%, #FFB400 100%);
    transform: scale(1.05);
    color: white;
}

.summary-note {
    text-align: center;
    color: #999;
    font-size: 0.85rem;
    margin-top: 15px;
    line-height: 1.6;
}

/* Badges */
.discount-badge {
    display: inline-block;
    background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%);
    color: white;
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 0.85rem;
    font-weight: 700;
    margin-left: 10px;
}

/* Responsive */
@media (max-width: 992px) {
    .summary-box {
        position: relative;
        top: 0;
        margin-top: 30px;
    }
}

@media (max-width: 768px) {
    .calculator-header h1 {
        font-size: 2rem;
    }
    
    .service-grid {
        grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
    }
    
    .calculator-form {
        padding: 25px;
    }
}
</style>

<!-- Header Section -->
<section class="calculator-header">
    <div class="container">
        <div class="calculator-header-content">
            <h1>Kalkulator Harga</h1>
            <p>Hitung biaya project digital Anda secara real-time</p>
        </div>
    </div>
</section>

<!-- Calculator Section -->
<section class="calculator-container">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <div class="calculator-form">
                    <!-- Service Selection -->
                    <div class="form-section">
                        <h3 class="section-title">
                            <i class="fas fa-shopping-cart"></i>
                            Pilih Layanan
                        </h3>
                        <p class="section-subtitle">Pilih satu atau lebih layanan yang Anda butuhkan</p>
                        
                        <div class="service-grid">
                            <?php foreach ($services as $service): ?>
                                <?php
                                $packages = getServicePackages($service['id']);
                                $packagesJson = json_encode($packages);
                                ?>
                                <div class="service-option">
                                    <input type="checkbox" 
                                           id="service-<?php echo $service['id']; ?>" 
                                           name="services[]" 
                                           value="<?php echo $service['id']; ?>"
                                           data-packages='<?php echo htmlspecialchars($packagesJson); ?>'
                                           onchange="toggleServicePackages(this)">
                                    <label for="service-<?php echo $service['id']; ?>" class="service-label">
                                        <i class="fas fa-laptop-code service-icon"></i>
                                        <div class="service-name"><?php echo htmlspecialchars($service['name']); ?></div>
                                        <div class="service-price">Mulai <?php echo formatRupiahShort($service['starting_price']); ?></div>
                                    </label>
                                    
                                    <!-- Package Selector (hidden by default) -->
                                    <div id="packages-<?php echo $service['id']; ?>" class="package-selector">
                                        <strong style="display: block; margin-bottom: 15px; color: #1E5C99;">Pilih Paket:</strong>
                                        <div class="package-options">
                                            <?php if (!empty($packages)): ?>
                                                <?php foreach ($packages as $idx => $package): ?>
                                                    <div class="package-option">
                                                        <input type="radio" 
                                                               id="package-<?php echo $service['id']; ?>-<?php echo $package['id']; ?>" 
                                                               name="package-<?php echo $service['id']; ?>" 
                                                               value="<?php echo $package['id']; ?>"
                                                               data-price="<?php echo $package['price']; ?>"
                                                               data-service-id="<?php echo $service['id']; ?>"
                                                               onchange="calculateTotal()"
                                                               <?php echo $idx === 0 ? 'checked' : ''; ?>>
                                                        <label for="package-<?php echo $service['id']; ?>-<?php echo $package['id']; ?>" class="package-label">
                                                            <div class="package-name"><?php echo htmlspecialchars($package['name']); ?></div>
                                                            <div class="package-price"><?php echo formatRupiahShort($package['price']); ?></div>
                                                        </label>
                                                    </div>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    
                    <!-- Add-ons -->
                    <div class="form-section">
                        <h3 class="section-title">
                            <i class="fas fa-plus-circle"></i>
                            Add-ons (Opsional)
                        </h3>
                        <p class="section-subtitle">Tingkatkan project Anda dengan add-ons tambahan</p>
                        
                        <div class="addon-grid">
                            <div class="addon-item">
                                <input type="checkbox" id="addon-seo" name="addons[]" value="seo" data-price="500000" onchange="calculateTotal()">
                                <div class="addon-info">
                                    <div class="addon-name">SEO Premium</div>
                                    <div class="addon-desc">Optimasi mesin pencari</div>
                                </div>
                                <div class="addon-price">+Rp 500rb</div>
                            </div>
                            
                            <div class="addon-item">
                                <input type="checkbox" id="addon-maintenance" name="addons[]" value="maintenance" data-price="300000" onchange="calculateTotal()">
                                <div class="addon-info">
                                    <div class="addon-name">Maintenance</div>
                                    <div class="addon-desc">Update & backup rutin</div>
                                </div>
                                <div class="addon-price">+Rp 300rb/bln</div>
                            </div>
                            
                            <div class="addon-item">
                                <input type="checkbox" id="addon-content" name="addons[]" value="content" data-price="750000" onchange="calculateTotal()">
                                <div class="addon-info">
                                    <div class="addon-name">Content Writing</div>
                                    <div class="addon-desc">10 artikel SEO friendly</div>
                                </div>
                                <div class="addon-price">+Rp 750rb</div>
                            </div>
                            
                            <div class="addon-item">
                                <input type="checkbox" id="addon-social" name="addons[]" value="social" data-price="1000000" onchange="calculateTotal()">
                                <div class="addon-info">
                                    <div class="addon-name">Social Media</div>
                                    <div class="addon-desc">Management 3 platform</div>
                                </div>
                                <div class="addon-price">+Rp 1jt/bln</div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Quantity -->
                    <div class="form-section">
                        <h3 class="section-title">
                            <i class="fas fa-sort-numeric-up"></i>
                            Jumlah
                        </h3>
                        <div class="quantity-control">
                            <span class="quantity-label">Jumlah Project:</span>
                            <div class="quantity-input">
                                <button type="button" class="quantity-btn" onclick="changeQuantity(-1)">-</button>
                                <input type="number" id="quantity" value="1" min="1" max="10" class="quantity-value" readonly>
                                <button type="button" class="quantity-btn" onclick="changeQuantity(1)">+</button>
                            </div>
                            <small style="color: #999;">Bundling discount otomatis!</small>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4">
                <div class="summary-box">
                    <h3 class="summary-title">Ringkasan Harga</h3>
                    
                    <div id="selectedItems"></div>
                    
                    <div class="summary-item">
                        <span class="summary-label">Subtotal</span>
                        <span class="summary-value" id="subtotal">Rp 0</span>
                    </div>
                    
                    <div id="discountSection" style="display: none;">
                        <div class="summary-discount">
                            <div class="summary-discount-label">Bundling Discount</div>
                            <div class="summary-discount-value" id="discountAmount">- Rp 0</div>
                        </div>
                    </div>
                    
                    <div class="summary-item">
                        <span class="summary-label">PPN (11%)</span>
                        <span class="summary-value" id="tax">Rp 0</span>
                    </div>
                    
                    <div class="summary-total">
                        <div class="summary-total-label">Total Pembayaran</div>
                        <div class="summary-total-value" id="total">Rp 0</div>
                    </div>
                    
                    <a href="#" id="orderBtn" class="summary-cta" onclick="sendOrder(event)">
                        <i class="fab fa-whatsapp"></i> Pesan Sekarang
                    </a>
                    
                    <p class="summary-note">
                        <i class="fas fa-info-circle"></i>
                        Harga sudah termasuk domain, hosting, dan SSL. 
                        Konsultasi gratis via WhatsApp!
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
// Toggle package selector visibility
function toggleServicePackages(checkbox) {
    const serviceId = checkbox.value;
    const packagesDiv = document.getElementById('packages-' + serviceId);
    
    if (checkbox.checked) {
        packagesDiv.classList.add('active');
    } else {
        packagesDiv.classList.remove('active');
    }
    
    calculateTotal();
}

// Change quantity
function changeQuantity(change) {
    const quantityInput = document.getElementById('quantity');
    let currentValue = parseInt(quantityInput.value);
    let newValue = currentValue + change;
    
    if (newValue >= 1 && newValue <= 10) {
        quantityInput.value = newValue;
        calculateTotal();
    }
}

// Calculate total
function calculateTotal() {
    let subtotal = 0;
    let selectedItems = [];
    
    // Get selected services and packages
    const serviceCheckboxes = document.querySelectorAll('input[name="services[]"]:checked');
    serviceCheckboxes.forEach(checkbox => {
        const serviceId = checkbox.value;
        const serviceName = checkbox.nextElementSibling.querySelector('.service-name').textContent;
        
        // Get selected package for this service
        const packageRadio = document.querySelector(`input[name="package-${serviceId}"]:checked`);
        if (packageRadio) {
            const packagePrice = parseInt(packageRadio.dataset.price);
            const packageName = packageRadio.nextElementSibling.querySelector('.package-name').textContent;
            
            subtotal += packagePrice;
            selectedItems.push({
                name: serviceName + ' - ' + packageName,
                price: packagePrice
            });
        }
    });
    
    // Get add-ons
    const addonCheckboxes = document.querySelectorAll('input[name="addons[]"]:checked');
    addonCheckboxes.forEach(checkbox => {
        const addonPrice = parseInt(checkbox.dataset.price);
        const addonName = checkbox.nextElementSibling.querySelector('.addon-name').textContent;
        
        subtotal += addonPrice;
        selectedItems.push({
            name: addonName,
            price: addonPrice
        });
    });
    
    // Get quantity
    const quantity = parseInt(document.getElementById('quantity').value);
    subtotal *= quantity;
    
    // Calculate bundling discount
    let discountPercent = 0;
    if (quantity >= 5) {
        discountPercent = 20;
    } else if (quantity >= 3) {
        discountPercent = 15;
    } else if (quantity >= 2) {
        discountPercent = 10;
    }
    
    const discount = subtotal * (discountPercent / 100);
    const afterDiscount = subtotal - discount;
    
    // Calculate tax (11%)
    const tax = afterDiscount * 0.11;
    
    // Calculate total
    const total = afterDiscount + tax;
    
    // Update UI
    updateSummary(selectedItems, subtotal, discount, discountPercent, tax, total);
}

// Update summary display
function updateSummary(items, subtotal, discount, discountPercent, tax, total) {
    // Update selected items
    const itemsHtml = items.map(item => `
        <div class="summary-item">
            <span class="summary-label">${item.name}</span>
            <span class="summary-value">${formatRupiah(item.price)}</span>
        </div>
    `).join('');
    document.getElementById('selectedItems').innerHTML = itemsHtml;
    
    // Update subtotal
    document.getElementById('subtotal').textContent = formatRupiah(subtotal);
    
    // Update discount
    if (discount > 0) {
        document.getElementById('discountSection').style.display = 'block';
        document.getElementById('discountAmount').innerHTML = `
            - ${formatRupiah(discount)} 
            <span class="discount-badge">${discountPercent}% OFF</span>
        `;
    } else {
        document.getElementById('discountSection').style.display = 'none';
    }
    
    // Update tax
    document.getElementById('tax').textContent = formatRupiah(tax);
    
    // Update total
    document.getElementById('total').textContent = formatRupiah(total);
}

// Format Rupiah
function formatRupiah(number) {
    return 'Rp ' + number.toLocaleString('id-ID');
}

// Send order via WhatsApp
function sendOrder(e) {
    e.preventDefault();
    
    const serviceCheckboxes = document.querySelectorAll('input[name="services[]"]:checked');
    if (serviceCheckboxes.length === 0) {
        alert('Silakan pilih minimal 1 layanan!');
        return;
    }
    
    let message = 'Halo! Saya tertarik memesan:\\n\\n';
    
    // Add services
    serviceCheckboxes.forEach(checkbox => {
        const serviceId = checkbox.value;
        const serviceName = checkbox.nextElementSibling.querySelector('.service-name').textContent;
        const packageRadio = document.querySelector(`input[name="package-${serviceId}"]:checked`);
        
        if (packageRadio) {
            const packageName = packageRadio.nextElementSibling.querySelector('.package-name').textContent;
            message += `✅ ${serviceName} (${packageName})\\n`;
        }
    });
    
    // Add addons
    const addonCheckboxes = document.querySelectorAll('input[name="addons[]"]:checked');
    if (addonCheckboxes.length > 0) {
        message += '\\n*Add-ons:*\\n';
        addonCheckboxes.forEach(checkbox => {
            const addonName = checkbox.nextElementSibling.querySelector('.addon-name').textContent;
            message += `+ ${addonName}\\n`;
        });
    }
    
    // Add quantity
    const quantity = document.getElementById('quantity').value;
    message += `\\n*Jumlah:* ${quantity} project\\n`;
    
    // Add total
    const total = document.getElementById('total').textContent;
    message += `\\n*Total Estimasi:* ${total}\\n\\n`;
    message += 'Mohon info lebih detail dan demo 24 jam. Terima kasih!';
    
    const whatsappUrl = '<?php echo WHATSAPP_URL; ?>?text=' + encodeURIComponent(message);
    window.open(whatsappUrl, '_blank');
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    calculateTotal();
});
</script>

<?php include __DIR__ . '/components/layout/footer.php'; ?>

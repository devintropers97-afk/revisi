<?php
/**
 * SITUNEO DIGITAL - Contact Page
 * Contact form with validation dan Google Maps integration
 */

require_once __DIR__ . '/includes/init.php';

// Page config
$currentPage = 'contact';
$pageTitle = 'Hubungi Kami';
$pageDescription = 'Hubungi SITUNEO DIGITAL untuk konsultasi gratis. Email: ' . ADMIN_EMAIL . ' | WhatsApp: ' . WHATSAPP_NUMBER;
$pageKeywords = 'kontak, hubungi kami, contact us, alamat';

// Handle form submission
$formSubmitted = false;
$formError = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_contact'])) {
    // Verify CSRF token
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $formError = 'Invalid security token. Please try again.';
    } else {
        // Validate inputs
        $name = cleanInput($_POST['name'] ?? '');
        $email = cleanInput($_POST['email'] ?? '');
        $phone = cleanInput($_POST['phone'] ?? '');
        $subject = cleanInput($_POST['subject'] ?? '');
        $message = cleanInput($_POST['message'] ?? '');
        
        $errors = [];
        
        if (empty($name)) {
            $errors[] = 'Nama wajib diisi';
        }
        
        if (empty($email) || !validateEmail($email)) {
            $errors[] = 'Email tidak valid';
        }
        
        if (empty($phone) || !validatePhone($phone)) {
            $errors[] = 'Nomor telepon tidak valid';
        }
        
        if (empty($subject)) {
            $errors[] = 'Subjek wajib diisi';
        }
        
        if (empty($message)) {
            $errors[] = 'Pesan wajib diisi';
        }
        
        if (empty($errors)) {
            // Save to database
            $result = $db->insert('contact_messages', [
                'name' => $name,
                'email' => $email,
                'phone' => $phone,
                'subject' => $subject,
                'message' => $message,
                'status' => 'unread',
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
            ]);
            
            if ($result) {
                $formSubmitted = true;
                
                // Send notification email to admin (optional)
                // sendContactNotification($name, $email, $phone, $subject, $message);
                
                // Clear form
                unset($_POST);
            } else {
                $formError = 'Gagal mengirim pesan. Silakan coba lagi.';
            }
        } else {
            $formError = implode('<br>', $errors);
        }
    }
}

// Include header
include __DIR__ . '/components/layout/header.php';
?>

<style>
/* Contact Page Styles */
.contact-header {
    background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%);
    padding: 100px 0 60px;
    position: relative;
    overflow: hidden;
}

.contact-header::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: url('data:image/svg+xml,<svg width="80" height="80" xmlns="http://www.w3.org/2000/svg"><circle cx="40" cy="40" r="30" fill="none" stroke="rgba(255,255,255,0.03)" stroke-width="2"/></svg>');
    background-size: 80px 80px;
}

.contact-header-content {
    position: relative;
    z-index: 2;
    text-align: center;
    color: white;
}

.contact-header h1 {
    font-size: 2.8rem;
    font-weight: 800;
    margin-bottom: 1rem;
    background: linear-gradient(135deg, #FFB400 0%, #FFD700 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.contact-header p {
    font-size: 1.2rem;
    opacity: 0.9;
}

/* Contact Container */
.contact-container {
    padding: 80px 0;
}

/* Contact Info Cards */
.contact-info-cards {
    margin-bottom: 60px;
}

.contact-info-card {
    background: white;
    border-radius: 20px;
    padding: 35px;
    text-align: center;
    box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    transition: all 0.3s ease;
    height: 100%;
    border-top: 4px solid #FFB400;
}

.contact-info-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 12px 40px rgba(0,0,0,0.15);
}

.contact-icon {
    width: 80px;
    height: 80px;
    background: linear-gradient(135deg, #FFB400 0%, #FFD700 100%);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 20px;
    font-size: 2rem;
    color: white;
}

.contact-info-card h3 {
    color: #1E5C99;
    font-size: 1.3rem;
    font-weight: 700;
    margin-bottom: 15px;
}

.contact-info-card p {
    color: #666;
    line-height: 1.8;
    margin-bottom: 0;
}

.contact-info-card a {
    color: #1E5C99;
    text-decoration: none;
    font-weight: 600;
    transition: color 0.3s ease;
}

.contact-info-card a:hover {
    color: #FFB400;
}

/* Contact Form */
.contact-form-section {
    background: white;
    border-radius: 24px;
    padding: 40px;
    box-shadow: 0 4px 30px rgba(0,0,0,0.08);
}

.form-title {
    color: #1E5C99;
    font-size: 2rem;
    font-weight: 800;
    margin-bottom: 10px;
}

.form-subtitle {
    color: #999;
    margin-bottom: 30px;
}

.form-group {
    margin-bottom: 25px;
}

.form-label {
    display: block;
    color: #333;
    font-weight: 600;
    margin-bottom: 8px;
}

.form-label .required {
    color: #f44336;
}

.form-control {
    width: 100%;
    padding: 14px 18px;
    border: 2px solid #e0e0e0;
    border-radius: 12px;
    font-size: 1rem;
    transition: all 0.3s ease;
    font-family: 'Inter', sans-serif;
}

.form-control:focus {
    outline: none;
    border-color: #1E5C99;
    box-shadow: 0 0 0 4px rgba(30, 92, 153, 0.1);
}

textarea.form-control {
    min-height: 150px;
    resize: vertical;
}

.form-alert {
    padding: 15px 20px;
    border-radius: 12px;
    margin-bottom: 25px;
}

.form-alert.success {
    background: #E8F5E9;
    color: #2E7D32;
    border-left: 4px solid #4CAF50;
}

.form-alert.error {
    background: #FFEBEE;
    color: #C62828;
    border-left: 4px solid #f44336;
}

.form-alert i {
    margin-right: 10px;
}

.submit-btn {
    width: 100%;
    padding: 16px;
    background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%);
    color: white;
    border: none;
    border-radius: 50px;
    font-weight: 700;
    font-size: 1.1rem;
    cursor: pointer;
    transition: all 0.3s ease;
}

.submit-btn:hover {
    background: linear-gradient(135deg, #0F3057 0%, #1E5C99 100%);
    transform: scale(1.02);
}

.submit-btn:disabled {
    opacity: 0.6;
    cursor: not-allowed;
}

/* Map Section */
.map-section {
    background: #f8f9fa;
    padding: 80px 0;
}

.map-container {
    background: white;
    border-radius: 24px;
    overflow: hidden;
    box-shadow: 0 4px 30px rgba(0,0,0,0.08);
}

.map-container iframe {
    width: 100%;
    height: 500px;
    border: none;
}

/* Social Links */
.social-links {
    background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%);
    padding: 60px 0;
    text-align: center;
    color: white;
}

.social-links h3 {
    font-size: 2rem;
    font-weight: 800;
    margin-bottom: 20px;
}

.social-links p {
    font-size: 1.1rem;
    opacity: 0.9;
    margin-bottom: 30px;
}

.social-icons {
    display: flex;
    justify-content: center;
    gap: 20px;
    flex-wrap: wrap;
}

.social-icon {
    width: 60px;
    height: 60px;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 1.5rem;
    text-decoration: none;
    transition: all 0.3s ease;
    backdrop-filter: blur(10px);
}

.social-icon:hover {
    background: linear-gradient(135deg, #FFB400 0%, #FFD700 100%);
    transform: scale(1.2) rotate(5deg);
}

/* Responsive */
@media (max-width: 768px) {
    .contact-header h1 {
        font-size: 2rem;
    }
    
    .contact-form-section {
        padding: 25px;
    }
    
    .map-container iframe {
        height: 350px;
    }
}
</style>

<!-- Header Section -->
<section class="contact-header">
    <div class="container">
        <div class="contact-header-content">
            <h1>Hubungi Kami</h1>
            <p>Kami siap membantu kebutuhan digital bisnis Anda</p>
        </div>
    </div>
</section>

<!-- Contact Info Cards -->
<section class="contact-container">
    <div class="container">
        <div class="contact-info-cards">
            <div class="row">
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="contact-info-card">
                        <div class="contact-icon">
                            <i class="fab fa-whatsapp"></i>
                        </div>
                        <h3>WhatsApp</h3>
                        <p>
                            Chat langsung dengan tim kami<br>
                            <a href="<?php echo WHATSAPP_URL; ?>" target="_blank">
                                <?php echo WHATSAPP_NUMBER; ?>
                            </a><br>
                            <small style="color: #999;">Respons dalam 5 menit</small>
                        </p>
                    </div>
                </div>
                
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="contact-info-card">
                        <div class="contact-icon">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <h3>Email</h3>
                        <p>
                            Kirim email ke:<br>
                            <a href="mailto:<?php echo ADMIN_EMAIL; ?>"><?php echo ADMIN_EMAIL; ?></a><br>
                            <a href="mailto:<?php echo SUPPORT_EMAIL; ?>"><?php echo SUPPORT_EMAIL; ?></a><br>
                            <small style="color: #999;">Respons dalam 1 jam</small>
                        </p>
                    </div>
                </div>
                
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="contact-info-card">
                        <div class="contact-icon">
                            <i class="fas fa-phone"></i>
                        </div>
                        <h3>Telepon</h3>
                        <p>
                            Hubungi kami di:<br>
                            <a href="tel:<?php echo str_replace([' ', '-'], '', COMPANY_PHONE); ?>">
                                <?php echo COMPANY_PHONE; ?>
                            </a><br>
                            <small style="color: #999;">
                                <?php echo BUSINESS_HOURS_START; ?> - <?php echo BUSINESS_HOURS_END; ?> WIB
                            </small>
                        </p>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <div class="contact-form-section">
                    <h2 class="form-title">Kirim Pesan</h2>
                    <p class="form-subtitle">Isi form di bawah dan kami akan segera menghubungi Anda</p>
                    
                    <?php if ($formSubmitted): ?>
                        <div class="form-alert success">
                            <i class="fas fa-check-circle"></i>
                            <strong>Terima kasih!</strong> Pesan Anda telah terkirim. 
                            Tim kami akan menghubungi Anda segera.
                        </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($formError)): ?>
                        <div class="form-alert error">
                            <i class="fas fa-exclamation-circle"></i>
                            <?php echo $formError; ?>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="" id="contactForm">
                        <?php echo csrf_field(); ?>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">
                                        Nama Lengkap <span class="required">*</span>
                                    </label>
                                    <input type="text" 
                                           name="name" 
                                           class="form-control" 
                                           placeholder="Masukkan nama lengkap"
                                           value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>"
                                           required>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">
                                        Email <span class="required">*</span>
                                    </label>
                                    <input type="email" 
                                           name="email" 
                                           class="form-control" 
                                           placeholder="nama@example.com"
                                           value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                                           required>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">
                                        Nomor WhatsApp <span class="required">*</span>
                                    </label>
                                    <input type="tel" 
                                           name="phone" 
                                           class="form-control" 
                                           placeholder="08123456789"
                                           value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>"
                                           required>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">
                                        Subjek <span class="required">*</span>
                                    </label>
                                    <select name="subject" class="form-control" required>
                                        <option value="">Pilih Subjek</option>
                                        <option value="Konsultasi Website">Konsultasi Website</option>
                                        <option value="Konsultasi Mobile App">Konsultasi Mobile App</option>
                                        <option value="Digital Marketing">Digital Marketing</option>
                                        <option value="Partnership">Partnership/Freelance</option>
                                        <option value="Komplain">Komplain</option>
                                        <option value="Lainnya">Lainnya</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">
                                Pesan <span class="required">*</span>
                            </label>
                            <textarea name="message" 
                                      class="form-control" 
                                      placeholder="Ceritakan kebutuhan Anda..."
                                      required><?php echo htmlspecialchars($_POST['message'] ?? ''); ?></textarea>
                        </div>
                        
                        <button type="submit" name="submit_contact" class="submit-btn">
                            <i class="fas fa-paper-plane"></i> Kirim Pesan
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Map Section -->
<section class="map-section">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">Lokasi Kami</h2>
            <p class="section-subtitle text-muted">Kunjungi kantor kami untuk konsultasi langsung</p>
        </div>
        
        <div class="map-container">
            <!-- Google Maps Embed - Replace with your actual location -->
            <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d126920.26168101448!2d106.68942999999999!3d-6.229728!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f3e945e34b9d%3A0x5371bf0fdad786a2!2sJakarta!5e0!3m2!1sen!2sid!4v1635000000000!5m2!1sen!2sid" 
                loading="lazy"
                allowfullscreen>
            </iframe>
        </div>
    </div>
</section>

<!-- Social Links -->
<section class="social-links">
    <div class="container">
        <h3>Ikuti Kami di Social Media</h3>
        <p>Dapatkan update terbaru, tips, dan promo eksklusif</p>
        
        <div class="social-icons">
            <a href="https://facebook.com/situneo" class="social-icon" target="_blank" title="Facebook">
                <i class="fab fa-facebook-f"></i>
            </a>
            <a href="https://instagram.com/situneo.digital" class="social-icon" target="_blank" title="Instagram">
                <i class="fab fa-instagram"></i>
            </a>
            <a href="https://twitter.com/situneo" class="social-icon" target="_blank" title="Twitter">
                <i class="fab fa-twitter"></i>
            </a>
            <a href="https://linkedin.com/company/situneo" class="social-icon" target="_blank" title="LinkedIn">
                <i class="fab fa-linkedin-in"></i>
            </a>
            <a href="https://youtube.com/@situneo" class="social-icon" target="_blank" title="YouTube">
                <i class="fab fa-youtube"></i>
            </a>
            <a href="https://tiktok.com/@situneo.digital" class="social-icon" target="_blank" title="TikTok">
                <i class="fab fa-tiktok"></i>
            </a>
        </div>
    </div>
</section>

<?php include __DIR__ . '/components/layout/footer.php'; ?>

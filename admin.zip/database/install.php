<?php
/**
 * SITUNEO DIGITAL - Database Installer
 * Automatically creates all 25 tables
 */

// Prevent direct access after installation
if (file_exists(__DIR__ . '/../config/installed.lock')) {
    die('⚠️ Database already installed! Delete config/installed.lock to reinstall.');
}

// Database credentials
$host = 'localhost';
$user = 'nrrskfvk_user_situneo_digital';
$pass = 'Devin1922$';
$db = 'nrrskfvk_situneo_digital';

// Connect to database
$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("❌ Connection failed: " . $conn->connect_error);
}

$conn->set_charset('utf8mb4');

// Get all migration files
$migrationPath = __DIR__ . '/migrations';
$migrations = glob($migrationPath . '/*.sql');
sort($migrations);

$success = 0;
$failed = 0;
$errors = [];

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SITUNEO DIGITAL - Database Installer</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .container {
            background: white;
            border-radius: 20px;
            padding: 40px;
            max-width: 800px;
            width: 100%;
            box-shadow: 0 10px 50px rgba(0,0,0,0.3);
        }
        h1 {
            color: #1E5C99;
            margin-bottom: 10px;
            font-size: 2rem;
        }
        .subtitle {
            color: #999;
            margin-bottom: 30px;
        }
        .info-box {
            background: #E3F2FD;
            border-left: 4px solid #1E5C99;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
        }
        .info-box strong { color: #1E5C99; }
        .progress-container {
            background: #f5f5f5;
            border-radius: 10px;
            padding: 20px;
            margin: 20px 0;
        }
        .progress-item {
            display: flex;
            align-items: center;
            padding: 10px;
            margin: 5px 0;
            background: white;
            border-radius: 8px;
            border-left: 4px solid #ddd;
        }
        .progress-item.success {
            border-left-color: #4CAF50;
            background: #E8F5E9;
        }
        .progress-item.error {
            border-left-color: #f44336;
            background: #FFEBEE;
        }
        .progress-item i {
            margin-right: 10px;
            font-size: 1.2rem;
        }
        .success-icon { color: #4CAF50; }
        .error-icon { color: #f44336; }
        .summary {
            background: linear-gradient(135deg, #FFB400 0%, #FFD700 100%);
            color: white;
            padding: 25px;
            border-radius: 12px;
            text-align: center;
            margin-top: 20px;
        }
        .summary h2 {
            margin-bottom: 15px;
            font-size: 1.8rem;
        }
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        .stat-item {
            background: rgba(255,255,255,0.2);
            padding: 15px;
            border-radius: 8px;
        }
        .stat-value {
            font-size: 2rem;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .btn {
            display: inline-block;
            padding: 12px 30px;
            background: white;
            color: #FFB400;
            text-decoration: none;
            border-radius: 50px;
            font-weight: bold;
            margin-top: 15px;
            transition: all 0.3s ease;
        }
        .btn:hover {
            background: #1E5C99;
            color: white;
            transform: scale(1.05);
        }
        .error-details {
            background: #FFEBEE;
            border: 1px solid #f44336;
            padding: 15px;
            border-radius: 8px;
            margin: 10px 0;
            color: #C62828;
            font-family: monospace;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🚀 SITUNEO DIGITAL</h1>
        <p class="subtitle">Database Installation</p>
        
        <div class="info-box">
            <strong>Database:</strong> <?php echo $db; ?><br>
            <strong>User:</strong> <?php echo $user; ?><br>
            <strong>Migrations:</strong> <?php echo count($migrations); ?> files
        </div>
        
        <div class="progress-container">
            <h3 style="margin-bottom: 15px; color: #1E5C99;">Installation Progress</h3>
            
            <?php
            foreach ($migrations as $migration) {
                $filename = basename($migration);
                $sql = file_get_contents($migration);
                
                echo '<div class="progress-item';
                
                if ($conn->multi_query($sql)) {
                    do {
                        if ($result = $conn->store_result()) {
                            $result->free();
                        }
                    } while ($conn->more_results() && $conn->next_result());
                    
                    echo ' success">';
                    echo '<span class="success-icon">✓</span>';
                    echo '<span>' . $filename . '</span>';
                    $success++;
                } else {
                    echo ' error">';
                    echo '<span class="error-icon">✗</span>';
                    echo '<span>' . $filename . '</span>';
                    $failed++;
                    $errors[] = [
                        'file' => $filename,
                        'error' => $conn->error
                    ];
                }
                
                echo '</div>';
                flush();
            }
            ?>
        </div>
        
        <?php if ($failed > 0): ?>
            <h3 style="color: #f44336; margin: 20px 0;">❌ Errors Occurred</h3>
            <?php foreach ($errors as $error): ?>
                <div class="error-details">
                    <strong><?php echo $error['file']; ?>:</strong><br>
                    <?php echo $error['error']; ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
        
        <div class="summary">
            <h2>
                <?php 
                if ($failed === 0) {
                    echo '🎉 Installation Completed Successfully!';
                } else {
                    echo '⚠️ Installation Completed with Errors';
                }
                ?>
            </h2>
            
            <div class="stats">
                <div class="stat-item">
                    <div class="stat-value"><?php echo $success; ?></div>
                    <div>Success</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value"><?php echo $failed; ?></div>
                    <div>Failed</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value"><?php echo count($migrations); ?></div>
                    <div>Total</div>
                </div>
            </div>
            
            <?php if ($failed === 0): ?>
                <p style="margin: 15px 0;">All database tables have been created successfully!</p>
                <a href="seed.php" class="btn">➡️ Continue to Seed Data</a>
                
                <?php
                // Create lock file
                $lockFile = __DIR__ . '/../config/installed.lock';
                file_put_contents($lockFile, date('Y-m-d H:i:s'));
                ?>
            <?php else: ?>
                <p style="margin: 15px 0;">Please fix the errors and try again.</p>
                <a href="install.php" class="btn">🔄 Retry Installation</a>
            <?php endif; ?>
        </div>
        
        <?php if ($failed === 0): ?>
            <div class="info-box" style="margin-top: 20px; background: #FFF3E0; border-left-color: #FF9800;">
                <strong>⚠️ IMPORTANT - Security:</strong><br>
                After completing the seed process, please <strong>DELETE</strong> this file (install.php) and seed.php for security!
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
<?php
$conn->close();
?>

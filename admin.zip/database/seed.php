<?php
/**
 * SITUNEO DIGITAL - Database Seeder
 * Automatically seeds initial data
 */

// Check if installed
if (!file_exists(__DIR__ . '/../config/installed.lock')) {
    die('⚠️ Please run install.php first!');
}

// Check if already seeded
if (file_exists(__DIR__ . '/../config/seeded.lock')) {
    die('⚠️ Database already seeded! Delete config/seeded.lock to re-seed.');
}

// Database credentials
$host = 'localhost';
$user = 'nrrskfvk_user_situneo_digital';
$pass = 'Devin1922$';
$db = 'nrrskfvk_situneo_digital';

// Connect to database
$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("❌ Connection failed: " . $conn->connect_error);
}

$conn->set_charset('utf8mb4');

// Get all seed files
$seedPath = __DIR__ . '/seeds';
$seeds = glob($seedPath . '/*.sql');
sort($seeds);

$success = 0;
$failed = 0;
$errors = [];

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SITUNEO DIGITAL - Database Seeder</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #0F3057 0%, #1E5C99 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .container {
            background: white;
            border-radius: 20px;
            padding: 40px;
            max-width: 800px;
            width: 100%;
            box-shadow: 0 10px 50px rgba(0,0,0,0.3);
        }
        h1 {
            color: #1E5C99;
            margin-bottom: 10px;
            font-size: 2rem;
        }
        .subtitle {
            color: #999;
            margin-bottom: 30px;
        }
        .info-box {
            background: #E8F5E9;
            border-left: 4px solid #4CAF50;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
        }
        .info-box strong { color: #2E7D32; }
        .progress-container {
            background: #f5f5f5;
            border-radius: 10px;
            padding: 20px;
            margin: 20px 0;
        }
        .progress-item {
            display: flex;
            align-items: center;
            padding: 10px;
            margin: 5px 0;
            background: white;
            border-radius: 8px;
            border-left: 4px solid #ddd;
        }
        .progress-item.success {
            border-left-color: #4CAF50;
            background: #E8F5E9;
        }
        .progress-item.error {
            border-left-color: #f44336;
            background: #FFEBEE;
        }
        .progress-item i {
            margin-right: 10px;
            font-size: 1.2rem;
        }
        .success-icon { color: #4CAF50; }
        .error-icon { color: #f44336; }
        .summary {
            background: linear-gradient(135deg, #4CAF50 0%, #66BB6A 100%);
            color: white;
            padding: 25px;
            border-radius: 12px;
            text-align: center;
            margin-top: 20px;
        }
        .summary h2 {
            margin-bottom: 15px;
            font-size: 1.8rem;
        }
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        .stat-item {
            background: rgba(255,255,255,0.2);
            padding: 15px;
            border-radius: 8px;
        }
        .stat-value {
            font-size: 2rem;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .btn {
            display: inline-block;
            padding: 12px 30px;
            background: white;
            color: #4CAF50;
            text-decoration: none;
            border-radius: 50px;
            font-weight: bold;
            margin: 10px 5px;
            transition: all 0.3s ease;
        }
        .btn:hover {
            background: #1E5C99;
            color: white;
            transform: scale(1.05);
        }
        .error-details {
            background: #FFEBEE;
            border: 1px solid #f44336;
            padding: 15px;
            border-radius: 8px;
            margin: 10px 0;
            color: #C62828;
            font-family: monospace;
            font-size: 0.9rem;
        }
        .credentials-box {
            background: #FFF3E0;
            border: 2px solid #FFB400;
            border-radius: 12px;
            padding: 20px;
            margin: 20px 0;
        }
        .credentials-box h3 {
            color: #FF9800;
            margin-bottom: 15px;
        }
        .credential-item {
            background: white;
            padding: 12px;
            margin: 8px 0;
            border-radius: 8px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .credential-label {
            font-weight: bold;
            color: #666;
        }
        .credential-value {
            color: #1E5C99;
            font-family: monospace;
            font-size: 1.1rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🌱 SITUNEO DIGITAL</h1>
        <p class="subtitle">Database Seeding</p>
        
        <div class="info-box">
            <strong>Database:</strong> <?php echo $db; ?><br>
            <strong>Seed Files:</strong> <?php echo count($seeds); ?> files
        </div>
        
        <div class="progress-container">
            <h3 style="margin-bottom: 15px; color: #1E5C99;">Seeding Progress</h3>
            
            <?php
            foreach ($seeds as $seed) {
                $filename = basename($seed);
                $sql = file_get_contents($seed);
                
                echo '<div class="progress-item';
                
                if ($conn->multi_query($sql)) {
                    do {
                        if ($result = $conn->store_result()) {
                            $result->free();
                        }
                    } while ($conn->more_results() && $conn->next_result());
                    
                    echo ' success">';
                    echo '<span class="success-icon">✓</span>';
                    echo '<span>' . $filename . '</span>';
                    $success++;
                } else {
                    echo ' error">';
                    echo '<span class="error-icon">✗</span>';
                    echo '<span>' . $filename . '</span>';
                    $failed++;
                    $errors[] = [
                        'file' => $filename,
                        'error' => $conn->error
                    ];
                }
                
                echo '</div>';
                flush();
            }
            ?>
        </div>
        
        <?php if ($failed > 0): ?>
            <h3 style="color: #f44336; margin: 20px 0;">❌ Errors Occurred</h3>
            <?php foreach ($errors as $error): ?>
                <div class="error-details">
                    <strong><?php echo $error['file']; ?>:</strong><br>
                    <?php echo $error['error']; ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
        
        <div class="summary">
            <h2>
                <?php 
                if ($failed === 0) {
                    echo '🎉 Seeding Completed Successfully!';
                } else {
                    echo '⚠️ Seeding Completed with Errors';
                }
                ?>
            </h2>
            
            <div class="stats">
                <div class="stat-item">
                    <div class="stat-value"><?php echo $success; ?></div>
                    <div>Success</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value"><?php echo $failed; ?></div>
                    <div>Failed</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value"><?php echo count($seeds); ?></div>
                    <div>Total</div>
                </div>
            </div>
            
            <?php if ($failed === 0): ?>
                <p style="margin: 15px 0;">All initial data has been seeded successfully!</p>
                <a href="/" class="btn">🏠 Go to Homepage</a>
                <a href="/admin/login.php" class="btn">🔐 Admin Login</a>
                
                <?php
                // Create seeded lock file
                $lockFile = __DIR__ . '/../config/seeded.lock';
                file_put_contents($lockFile, date('Y-m-d H:i:s'));
                ?>
            <?php else: ?>
                <p style="margin: 15px 0;">Please fix the errors and try again.</p>
                <a href="seed.php" class="btn">🔄 Retry Seeding</a>
            <?php endif; ?>
        </div>
        
        <?php if ($failed === 0): ?>
            <div class="credentials-box">
                <h3>🔑 Default Admin Credentials</h3>
                <div class="credential-item">
                    <span class="credential-label">Email:</span>
                    <span class="credential-value">admin@situneo.my.id</span>
                </div>
                <div class="credential-item">
                    <span class="credential-label">Password:</span>
                    <span class="credential-value">admin123</span>
                </div>
                <p style="color: #f44336; margin-top: 15px; font-weight: bold;">
                    ⚠️ IMPORTANT: Please change this password immediately after first login!
                </p>
            </div>
            
            <div class="info-box" style="background: #FFEBEE; border-left-color: #f44336;">
                <strong>⚠️ CRITICAL - Security:</strong><br>
                Please <strong>DELETE</strong> the following files NOW for security:<br>
                • database/install.php<br>
                • database/seed.php
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
<?php
$conn->close();
?>

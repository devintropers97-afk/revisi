<?php
/**
 * Quick Diagnostic
 * Cek files & functions availability
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo '<html><head><title>Diagnostic - SITUNEO</title>';
echo '<style>
body { font-family: monospace; padding: 20px; background: #f5f5f5; }
.pass { color: green; font-weight: bold; }
.fail { color: red; font-weight: bold; }
.section { background: white; padding: 15px; margin: 10px 0; border-radius: 5px; }
h2 { color: #1E5C99; border-bottom: 2px solid #FFB400; padding-bottom: 5px; }
</style></head><body>';

echo '<h1>🔍 SITUNEO Diagnostic</h1>';

// CHECK 1: Files Existence
echo '<div class="section">';
echo '<h2>1. Files Existence Check</h2>';

$files = [
    'includes/init.php',
    'config/database.php',
    'config/constants.php',
    'includes/services/service-functions.php',
    'includes/services/pricing-calculator.php',
    'includes/services/commission-calculator.php',
    'includes/services/tier-checker.php',
    'includes/services/order-processor.php',
    'database/seed.php',
    'database/install.php'
];

foreach ($files as $file) {
    $exists = file_exists($file);
    $status = $exists ? '<span class="pass">✅ EXISTS</span>' : '<span class="fail">❌ NOT FOUND</span>';
    echo "- {$file}: {$status}<br>";
}
echo '</div>';

// CHECK 2: Load init.php
echo '<div class="section">';
echo '<h2>2. Loading init.php</h2>';
try {
    require_once 'includes/init.php';
    echo '<span class="pass">✅ init.php loaded successfully</span><br>';
} catch (Exception $e) {
    echo '<span class="fail">❌ ERROR loading init.php</span><br>';
    echo 'Error: ' . $e->getMessage() . '<br>';
}
echo '</div>';

// CHECK 3: Database class
echo '<div class="section">';
echo '<h2>3. Database Class Check</h2>';

if (class_exists('Database')) {
    echo '<span class="pass">✅ Database class exists</span><br>';
    
    // Check methods
    $methods = get_class_methods('Database');
    echo 'Available methods: ' . implode(', ', $methods) . '<br>';
    
    // Check getInstance
    if (method_exists('Database', 'getInstance')) {
        echo '<span class="pass">✅ getInstance() method exists</span><br>';
    } else {
        echo '<span class="fail">❌ getInstance() method NOT FOUND</span><br>';
        echo 'Available static methods: ';
        $reflection = new ReflectionClass('Database');
        foreach ($reflection->getMethods(ReflectionMethod::IS_STATIC) as $method) {
            echo $method->name . ', ';
        }
        echo '<br>';
    }
} else {
    echo '<span class="fail">❌ Database class NOT FOUND</span><br>';
    echo 'Declared classes: ' . implode(', ', get_declared_classes()) . '<br>';
}
echo '</div>';

// CHECK 4: Service Functions
echo '<div class="section">';
echo '<h2>4. Service Functions Check</h2>';

$functions = [
    'getServices',
    'getServiceById',
    'getFeaturedServices',
    'calculateOrderPrice',
    'calculateCommission',
    'formatRupiah',
    'formatDate',
    'formatPhone'
];

foreach ($functions as $func) {
    $exists = function_exists($func);
    $status = $exists ? '<span class="pass">✅ EXISTS</span>' : '<span class="fail">❌ NOT FOUND</span>';
    echo "- {$func}(): {$status}<br>";
}
echo '</div>';

// CHECK 5: Constants
echo '<div class="section">';
echo '<h2>5. Constants Check</h2>';

$constants = [
    'DB_HOST',
    'DB_USER',
    'DB_PASS',
    'DB_NAME',
    'COMPANY_NAME',
    'COMPANY_NIB',
    'CONTACT_WHATSAPP',
    'BASE_PATH'
];

foreach ($constants as $const) {
    $exists = defined($const);
    $status = $exists ? '<span class="pass">✅ DEFINED</span>' : '<span class="fail">❌ NOT DEFINED</span>';
    $value = $exists ? constant($const) : 'N/A';
    echo "- {$const}: {$status} = " . htmlspecialchars($value) . "<br>";
}
echo '</div>';

// CHECK 6: Database Connection
echo '<div class="section">';
echo '<h2>6. Database Connection Test</h2>';

try {
    // Try different connection methods
    if (class_exists('Database')) {
        if (method_exists('Database', 'getInstance')) {
            $db = Database::getInstance();
            echo '<span class="pass">✅ Connected via getInstance()</span><br>';
        } elseif (method_exists('Database', 'connect')) {
            $db = Database::connect();
            echo '<span class="pass">✅ Connected via connect()</span><br>';
        } else {
            // Try direct mysqli
            if (defined('DB_HOST') && defined('DB_USER') && defined('DB_PASS') && defined('DB_NAME')) {
                $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
                if ($conn->connect_error) {
                    echo '<span class="fail">❌ Connection failed: ' . $conn->connect_error . '</span><br>';
                } else {
                    echo '<span class="pass">✅ Connected via direct mysqli</span><br>';
                    echo 'Database: ' . DB_NAME . '<br>';
                    $conn->close();
                }
            } else {
                echo '<span class="fail">❌ Database constants not defined</span><br>';
            }
        }
    } else {
        echo '<span class="fail">❌ Database class not found</span><br>';
    }
} catch (Exception $e) {
    echo '<span class="fail">❌ Connection ERROR: ' . $e->getMessage() . '</span><br>';
}
echo '</div>';

echo '<div class="section" style="background: #1E5C99; color: white;">';
echo '<h2 style="color: white; border-bottom-color: #FFB400;">📋 Summary</h2>';
echo '<p>Copy hasil diagnostic ini dan kirim ke developer untuk analisis.</p>';
echo '</div>';

echo '</body></html>';
?>
```

---

## 🚀 CARA PAKAI DIAGNOSTIC

**1. Buat file `diagnostic.php` di root:**

Via cPanel File Manager:
- New File → `diagnostic.php`
- Edit → Paste code di atas
- Save

**2. Akses:**
```
http://situneo.my.id/diagnostic.php
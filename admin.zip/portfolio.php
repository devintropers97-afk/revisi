<?php
/**
 * SITUNEO DIGITAL - Portfolio Page
 * Showcase portfolio projects dengan filters dan detail modal
 */

require_once __DIR__ . '/includes/init.php';

// Page config
$currentPage = 'portfolio';
$pageTitle = 'Portfolio';
$pageDescription = 'Lihat portfolio project yang telah kami kerjakan. 500+ project selesai dengan rating kepuasan 4.9/5.0 dari berbagai industri.';
$pageKeywords = 'portfolio web, showcase project, portfolio design, web development portfolio';

// Get filters
$categoryFilter = isset($_GET['category']) ? trim($_GET['category']) : '';

// Get portfolios
$query = "SELECT p.*, sc.name as category_name 
          FROM portfolios p 
          LEFT JOIN service_categories sc ON p.category_id = sc.id 
          WHERE p.is_published = 1";

if (!empty($categoryFilter)) {
    $query .= " AND sc.slug = '" . $db->conn->real_escape_string($categoryFilter) . "'";
}

$query .= " ORDER BY p.order_position ASC, p.created_at DESC";
$portfolios = $db->fetchAll($query);

// Get unique categories from portfolios
$categories = $db->fetchAll("
    SELECT DISTINCT sc.id, sc.name, sc.slug 
    FROM portfolios p 
    JOIN service_categories sc ON p.category_id = sc.id 
    WHERE p.is_published = 1 
    ORDER BY sc.name ASC
");

// Include header
include __DIR__ . '/components/layout/header.php';
?>

<style>
/* Portfolio Page Styles */
.portfolio-header {
    background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%);
    padding: 100px 0 60px;
    position: relative;
    overflow: hidden;
}

.portfolio-header::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: url('data:image/svg+xml,<svg width="60" height="60" xmlns="http://www.w3.org/2000/svg"><rect width="60" height="60" fill="none" stroke="rgba(255,255,255,0.03)" stroke-width="1"/></svg>');
    background-size: 60px 60px;
}

.portfolio-header-content {
    position: relative;
    z-index: 2;
    text-align: center;
    color: white;
}

.portfolio-header h1 {
    font-size: 2.8rem;
    font-weight: 800;
    margin-bottom: 1rem;
    background: linear-gradient(135deg, #FFB400 0%, #FFD700 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.portfolio-header p {
    font-size: 1.2rem;
    opacity: 0.9;
}

/* Filter Buttons */
.portfolio-filters {
    background: white;
    padding: 30px 0;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    position: sticky;
    top: 0;
    z-index: 100;
}

.filter-buttons {
    display: flex;
    justify-content: center;
    gap: 12px;
    flex-wrap: wrap;
}

.filter-btn {
    padding: 12px 28px;
    border: 2px solid #e0e0e0;
    background: white;
    border-radius: 50px;
    cursor: pointer;
    transition: all 0.3s ease;
    font-weight: 600;
    color: #666;
    text-decoration: none;
    display: inline-block;
}

.filter-btn:hover, .filter-btn.active {
    background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%);
    color: white;
    border-color: #1E5C99;
}

/* Portfolio Grid */
.portfolio-grid {
    padding: 60px 0;
}

.portfolio-item {
    margin-bottom: 30px;
    position: relative;
    overflow: hidden;
    border-radius: 16px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    transition: all 0.3s ease;
    cursor: pointer;
}

.portfolio-item:hover {
    transform: translateY(-8px);
    box-shadow: 0 12px 40px rgba(0,0,0,0.15);
}

.portfolio-image {
    position: relative;
    padding-top: 75%;
    overflow: hidden;
    background: #f5f5f5;
}

.portfolio-image img {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.5s ease;
}

.portfolio-item:hover .portfolio-image img {
    transform: scale(1.15);
}

.portfolio-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(180deg, transparent 0%, rgba(0,0,0,0.85) 100%);
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    padding: 25px;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.portfolio-item:hover .portfolio-overlay {
    opacity: 1;
}

.portfolio-category {
    display: inline-block;
    background: linear-gradient(135deg, #FFB400 0%, #FFD700 100%);
    color: white;
    padding: 6px 16px;
    border-radius: 50px;
    font-size: 0.85rem;
    font-weight: 600;
    margin-bottom: 12px;
}

.portfolio-title {
    color: white;
    font-size: 1.4rem;
    font-weight: 700;
    margin-bottom: 8px;
}

.portfolio-description {
    color: rgba(255,255,255,0.9);
    font-size: 0.95rem;
    margin-bottom: 15px;
    line-height: 1.6;
}

.portfolio-tags {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.portfolio-tag {
    background: rgba(255,255,255,0.2);
    color: white;
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 0.8rem;
    backdrop-filter: blur(10px);
}

.portfolio-icon {
    position: absolute;
    top: 20px;
    right: 20px;
    width: 50px;
    height: 50px;
    background: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #1E5C99;
    font-size: 1.5rem;
    opacity: 0;
    transform: scale(0);
    transition: all 0.3s ease;
}

.portfolio-item:hover .portfolio-icon {
    opacity: 1;
    transform: scale(1);
}

/* Featured Badge */
.portfolio-featured {
    position: absolute;
    top: 20px;
    left: 20px;
    background: linear-gradient(135deg, #FFB400 0%, #FFD700 100%);
    color: white;
    padding: 8px 16px;
    border-radius: 50px;
    font-size: 0.85rem;
    font-weight: 600;
    z-index: 2;
}

/* Modal Lightbox */
.portfolio-modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.95);
    z-index: 9999;
    padding: 20px;
    overflow-y: auto;
}

.portfolio-modal.active {
    display: flex;
    align-items: center;
    justify-content: center;
}

.modal-content {
    background: white;
    border-radius: 20px;
    max-width: 900px;
    width: 100%;
    max-height: 90vh;
    overflow-y: auto;
    position: relative;
}

.modal-close {
    position: absolute;
    top: 20px;
    right: 20px;
    width: 40px;
    height: 40px;
    background: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    z-index: 10;
    box-shadow: 0 4px 15px rgba(0,0,0,0.2);
    transition: all 0.3s ease;
}

.modal-close:hover {
    background: #f44336;
    color: white;
    transform: rotate(90deg);
}

.modal-image {
    width: 100%;
    border-radius: 20px 20px 0 0;
}

.modal-body {
    padding: 40px;
}

.modal-body h2 {
    color: #1E5C99;
    font-size: 2rem;
    font-weight: 800;
    margin-bottom: 10px;
}

.modal-body .category {
    display: inline-block;
    background: linear-gradient(135deg, #FFB400 0%, #FFD700 100%);
    color: white;
    padding: 6px 16px;
    border-radius: 50px;
    font-size: 0.9rem;
    font-weight: 600;
    margin-bottom: 20px;
}

.modal-body p {
    color: #666;
    line-height: 1.8;
    margin-bottom: 25px;
}

.modal-info {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin-bottom: 25px;
    padding: 25px;
    background: #f8f9fa;
    border-radius: 12px;
}

.info-item {
    display: flex;
    align-items: center;
    gap: 12px;
}

.info-item i {
    color: #FFB400;
    font-size: 1.3rem;
}

.info-item div {
    flex: 1;
}

.info-label {
    font-size: 0.85rem;
    color: #999;
    margin-bottom: 4px;
}

.info-value {
    font-weight: 600;
    color: #333;
}

.modal-tags {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.modal-tag {
    background: #e3f2fd;
    color: #1E5C99;
    padding: 8px 16px;
    border-radius: 20px;
    font-size: 0.9rem;
    font-weight: 600;
}

.modal-cta {
    margin-top: 30px;
    text-align: center;
}

/* Stats Section */
.portfolio-stats {
    background: #f8f9fa;
    padding: 60px 0;
    text-align: center;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 30px;
    max-width: 900px;
    margin: 0 auto;
}

.stat-item {
    background: white;
    padding: 30px;
    border-radius: 16px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.05);
}

.stat-number {
    font-size: 2.5rem;
    font-weight: 800;
    color: #FFB400;
    margin-bottom: 8px;
}

.stat-label {
    color: #666;
    font-size: 1rem;
}

/* Responsive */
@media (max-width: 768px) {
    .portfolio-header h1 {
        font-size: 2rem;
    }
    
    .filter-buttons {
        gap: 8px;
    }
    
    .filter-btn {
        padding: 8px 16px;
        font-size: 0.9rem;
    }
    
    .modal-body {
        padding: 25px;
    }
    
    .modal-body h2 {
        font-size: 1.5rem;
    }
}
</style>

<!-- Header Section -->
<section class="portfolio-header">
    <div class="container">
        <div class="portfolio-header-content">
            <h1>Portfolio Kami</h1>
            <p>500+ project selesai dengan rating kepuasan 4.9/5.0</p>
        </div>
    </div>
</section>

<!-- Filters Section -->
<section class="portfolio-filters">
    <div class="container">
        <div class="filter-buttons">
            <a href="/portfolio.php" class="filter-btn <?php echo empty($categoryFilter) ? 'active' : ''; ?>">
                Semua Project
            </a>
            <?php foreach ($categories as $cat): ?>
                <a href="/portfolio.php?category=<?php echo $cat['slug']; ?>" 
                   class="filter-btn <?php echo $categoryFilter === $cat['slug'] ? 'active' : ''; ?>">
                    <?php echo htmlspecialchars($cat['name']); ?>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Portfolio Grid -->
<section class="portfolio-grid">
    <div class="container">
        <?php if (empty($portfolios)): ?>
            <div class="text-center py-5">
                <i class="fas fa-folder-open" style="font-size: 5rem; color: #ddd;"></i>
                <h3 class="mt-3 text-muted">Belum Ada Portfolio</h3>
                <p class="text-muted">Portfolio akan segera ditambahkan</p>
            </div>
        <?php else: ?>
            <div class="row">
                <?php foreach ($portfolios as $portfolio): ?>
                    <?php
                    $imageUrl = !empty($portfolio['image']) 
                        ? $portfolio['image'] 
                        : 'https://source.unsplash.com/800x600/?' . urlencode($portfolio['title']);
                    
                    $tags = !empty($portfolio['tags']) ? json_decode($portfolio['tags'], true) : [];
                    ?>
                    
                    <div class="col-lg-4 col-md-6">
                        <div class="portfolio-item" onclick="openPortfolioModal(<?php echo $portfolio['id']; ?>)">
                            <?php if ($portfolio['is_featured']): ?>
                                <span class="portfolio-featured">
                                    <i class="fas fa-star"></i> Featured
                                </span>
                            <?php endif; ?>
                            
                            <div class="portfolio-image">
                                <img src="<?php echo $imageUrl; ?>" 
                                     alt="<?php echo htmlspecialchars($portfolio['title']); ?>">
                                <div class="portfolio-icon">
                                    <i class="fas fa-search-plus"></i>
                                </div>
                            </div>
                            
                            <div class="portfolio-overlay">
                                <span class="portfolio-category">
                                    <?php echo htmlspecialchars($portfolio['category_name'] ?? 'Project'); ?>
                                </span>
                                <h3 class="portfolio-title">
                                    <?php echo htmlspecialchars($portfolio['title']); ?>
                                </h3>
                                <p class="portfolio-description">
                                    <?php echo htmlspecialchars(substr($portfolio['description'], 0, 100)) . '...'; ?>
                                </p>
                                <?php if (!empty($tags)): ?>
                                    <div class="portfolio-tags">
                                        <?php foreach (array_slice($tags, 0, 3) as $tag): ?>
                                            <span class="portfolio-tag"><?php echo htmlspecialchars($tag); ?></span>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <!-- Modal Data (hidden) -->
                        <div id="portfolio-data-<?php echo $portfolio['id']; ?>" style="display: none;">
                            <?php echo json_encode([
                                'id' => $portfolio['id'],
                                'title' => $portfolio['title'],
                                'description' => $portfolio['description'],
                                'category' => $portfolio['category_name'] ?? 'Project',
                                'client' => $portfolio['client_name'] ?? '-',
                                'date' => formatDate($portfolio['project_date']),
                                'url' => $portfolio['project_url'] ?? '#',
                                'image' => $imageUrl,
                                'tags' => $tags
                            ]); ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<!-- Stats Section -->
<section class="portfolio-stats">
    <div class="container">
        <h2 class="section-title mb-5">Pencapaian Kami</h2>
        <div class="stats-grid">
            <div class="stat-item">
                <div class="stat-number"><?php echo STATS_PROJECTS; ?></div>
                <div class="stat-label">Project Selesai</div>
            </div>
            <div class="stat-item">
                <div class="stat-number"><?php echo STATS_CLIENTS; ?></div>
                <div class="stat-label">Klien Puas</div>
            </div>
            <div class="stat-item">
                <div class="stat-number"><?php echo STATS_SATISFACTION; ?></div>
                <div class="stat-label">Rating Kepuasan</div>
            </div>
            <div class="stat-item">
                <div class="stat-number"><?php echo STATS_EXPERIENCE_YEARS; ?></div>
                <div class="stat-label">Tahun Pengalaman</div>
            </div>
        </div>
    </div>
</section>

<!-- Modal Lightbox -->
<div id="portfolioModal" class="portfolio-modal" onclick="closePortfolioModal(event)">
    <div class="modal-content" onclick="event.stopPropagation()">
        <div class="modal-close" onclick="closePortfolioModal()">
            <i class="fas fa-times"></i>
        </div>
        <img id="modalImage" class="modal-image" src="" alt="">
        <div class="modal-body">
            <h2 id="modalTitle"></h2>
            <span id="modalCategory" class="category"></span>
            <p id="modalDescription"></p>
            
            <div class="modal-info">
                <div class="info-item">
                    <i class="fas fa-user"></i>
                    <div>
                        <div class="info-label">Client</div>
                        <div class="info-value" id="modalClient"></div>
                    </div>
                </div>
                <div class="info-item">
                    <i class="fas fa-calendar"></i>
                    <div>
                        <div class="info-label">Tanggal</div>
                        <div class="info-value" id="modalDate"></div>
                    </div>
                </div>
            </div>
            
            <div id="modalTags" class="modal-tags"></div>
            
            <div class="modal-cta">
                <a href="<?php echo whatsappUrl('Halo! Saya tertarik dengan portfolio yang saya lihat'); ?>" 
                   class="btn btn-gold btn-lg" target="_blank">
                    <i class="fab fa-whatsapp"></i> Konsultasi Project Serupa
                </a>
            </div>
        </div>
    </div>
</div>

<script>
function openPortfolioModal(id) {
    const dataElement = document.getElementById('portfolio-data-' + id);
    if (!dataElement) return;
    
    const data = JSON.parse(dataElement.textContent);
    const modal = document.getElementById('portfolioModal');
    
    // Populate modal
    document.getElementById('modalImage').src = data.image;
    document.getElementById('modalTitle').textContent = data.title;
    document.getElementById('modalCategory').textContent = data.category;
    document.getElementById('modalDescription').textContent = data.description;
    document.getElementById('modalClient').textContent = data.client;
    document.getElementById('modalDate').textContent = data.date;
    
    // Tags
    const tagsContainer = document.getElementById('modalTags');
    tagsContainer.innerHTML = '';
    if (data.tags && data.tags.length > 0) {
        data.tags.forEach(tag => {
            const span = document.createElement('span');
            span.className = 'modal-tag';
            span.textContent = tag;
            tagsContainer.appendChild(span);
        });
    }
    
    // Show modal
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closePortfolioModal(event) {
    if (event && event.target.closest('.modal-content')) return;
    
    const modal = document.getElementById('portfolioModal');
    modal.classList.remove('active');
    document.body.style.overflow = '';
}

// Close on Escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closePortfolioModal();
    }
});
</script>

<?php include __DIR__ . '/components/layout/footer.php'; ?>

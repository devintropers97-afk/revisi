<?php
/**
 * SITUNEO DIGITAL - Pricing Page
 * Full pricing comparison table dengan tier system dan package details
 */

require_once __DIR__ . '/includes/init.php';

// Page config
$currentPage = 'pricing';
$pageTitle = 'Harga & Paket';
$pageDescription = 'Lihat daftar harga dan paket layanan SITUNEO DIGITAL. Website mulai dari Rp 150.000/bulan dengan berbagai paket sesuai kebutuhan Anda.';
$pageKeywords = 'harga website, paket website, biaya pembuatan website, price list';

// Get featured services with packages
$featuredServices = $db->fetchAll("
    SELECT s.*, sc.name as category_name 
    FROM services s 
    LEFT JOIN service_categories sc ON s.category_id = sc.id 
    WHERE s.is_featured = 1 AND s.is_active = 1 
    ORDER BY s.order_position ASC 
    LIMIT 6
");

// Include header
include __DIR__ . '/components/layout/header.php';
?>

<style>
/* Pricing Page Styles */
.pricing-header {
    background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%);
    padding: 100px 0 60px;
    position: relative;
    overflow: hidden;
}

.pricing-header::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: url('data:image/svg+xml,<svg width="80" height="80" xmlns="http://www.w3.org/2000/svg"><circle cx="40" cy="40" r="30" fill="none" stroke="rgba(255,255,255,0.03)" stroke-width="2"/></svg>');
    background-size: 80px 80px;
}

.pricing-header-content {
    position: relative;
    z-index: 2;
    text-align: center;
    color: white;
}

.pricing-header h1 {
    font-size: 2.8rem;
    font-weight: 800;
    margin-bottom: 1rem;
    background: linear-gradient(135deg, #FFB400 0%, #FFD700 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.pricing-header p {
    font-size: 1.2rem;
    opacity: 0.9;
}

/* Main Pricing Cards */
.main-pricing {
    padding: 80px 0;
}

.pricing-card {
    background: white;
    border-radius: 24px;
    padding: 40px;
    text-align: center;
    box-shadow: 0 4px 30px rgba(0,0,0,0.08);
    transition: all 0.3s ease;
    position: relative;
    height: 100%;
    display: flex;
    flex-direction: column;
}

.pricing-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 12px 50px rgba(0,0,0,0.15);
}

.pricing-card.featured {
    background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%);
    color: white;
    transform: scale(1.05);
}

.pricing-card.featured:hover {
    transform: scale(1.08) translateY(-10px);
}

.pricing-badge {
    position: absolute;
    top: -15px;
    left: 50%;
    transform: translateX(-50%);
    background: linear-gradient(135deg, #FFB400 0%, #FFD700 100%);
    color: white;
    padding: 8px 24px;
    border-radius: 50px;
    font-size: 0.85rem;
    font-weight: 700;
    text-transform: uppercase;
}

.pricing-icon {
    width: 80px;
    height: 80px;
    background: linear-gradient(135deg, #FFB400 0%, #FFD700 100%);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 25px;
    font-size: 2.5rem;
    color: white;
}

.pricing-card.featured .pricing-icon {
    background: white;
    color: #1E5C99;
}

.pricing-title {
    font-size: 1.8rem;
    font-weight: 800;
    margin-bottom: 10px;
    color: #1E5C99;
}

.pricing-card.featured .pricing-title {
    color: #FFD700;
}

.pricing-subtitle {
    color: #999;
    font-size: 0.95rem;
    margin-bottom: 25px;
}

.pricing-card.featured .pricing-subtitle {
    color: rgba(255,255,255,0.8);
}

.pricing-price {
    margin-bottom: 30px;
}

.price-amount {
    font-size: 3rem;
    font-weight: 900;
    color: #1E5C99;
    line-height: 1;
}

.pricing-card.featured .price-amount {
    color: #FFD700;
}

.price-period {
    color: #999;
    font-size: 1rem;
    margin-top: 8px;
}

.pricing-card.featured .price-period {
    color: rgba(255,255,255,0.7);
}

.pricing-features {
    list-style: none;
    padding: 0;
    margin: 0 0 30px 0;
    text-align: left;
    flex-grow: 1;
}

.pricing-features li {
    padding: 12px 0;
    display: flex;
    align-items: flex-start;
    color: #666;
}

.pricing-card.featured .pricing-features li {
    color: rgba(255,255,255,0.9);
}

.pricing-features li i {
    color: #FFB400;
    margin-right: 12px;
    margin-top: 4px;
    font-size: 1.1rem;
}

.pricing-card.featured .pricing-features li i {
    color: #FFD700;
}

.pricing-cta {
    width: 100%;
    padding: 16px;
    border-radius: 50px;
    font-weight: 700;
    font-size: 1.1rem;
    border: none;
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
    display: inline-block;
}

.pricing-card:not(.featured) .pricing-cta {
    background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%);
    color: white;
}

.pricing-card:not(.featured) .pricing-cta:hover {
    background: linear-gradient(135deg, #0F3057 0%, #1E5C99 100%);
    transform: scale(1.05);
}

.pricing-card.featured .pricing-cta {
    background: linear-gradient(135deg, #FFB400 0%, #FFD700 100%);
    color: white;
}

.pricing-card.featured .pricing-cta:hover {
    background: linear-gradient(135deg, #FFD700 0%, #FFB400 100%);
    transform: scale(1.05);
}

/* Services Pricing */
.services-pricing {
    padding: 80px 0;
    background: #f8f9fa;
}

.service-pricing-card {
    background: white;
    border-radius: 20px;
    padding: 35px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.06);
    transition: all 0.3s ease;
    margin-bottom: 30px;
    border-left: 5px solid #FFB400;
}

.service-pricing-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 30px rgba(0,0,0,0.12);
}

.service-pricing-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 20px;
}

.service-pricing-info h3 {
    color: #1E5C99;
    font-size: 1.5rem;
    font-weight: 700;
    margin-bottom: 8px;
}

.service-pricing-info .category {
    color: #999;
    font-size: 0.9rem;
}

.service-pricing-price {
    text-align: right;
}

.price-label {
    color: #999;
    font-size: 0.85rem;
    margin-bottom: 4px;
}

.price-value {
    color: #FFB400;
    font-size: 1.8rem;
    font-weight: 800;
}

.service-pricing-desc {
    color: #666;
    line-height: 1.7;
    margin-bottom: 20px;
}

.package-list {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 15px;
    margin-bottom: 20px;
}

.package-item {
    background: #f8f9fa;
    padding: 15px;
    border-radius: 12px;
    border: 2px solid transparent;
    transition: all 0.3s ease;
    cursor: pointer;
}

.package-item:hover {
    border-color: #FFB400;
    background: #fff;
}

.package-name {
    font-weight: 700;
    color: #1E5C99;
    margin-bottom: 5px;
}

.package-price {
    color: #FFB400;
    font-size: 1.2rem;
    font-weight: 700;
}

.service-pricing-cta {
    display: flex;
    gap: 10px;
}

.service-pricing-cta a {
    flex: 1;
    text-align: center;
}

/* Tier System */
.tier-system {
    padding: 80px 0;
    background: white;
}

.tier-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 25px;
    margin-top: 40px;
}

.tier-card {
    background: white;
    border-radius: 20px;
    padding: 35px;
    text-align: center;
    box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    transition: all 0.3s ease;
    border: 3px solid transparent;
}

.tier-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 12px 40px rgba(0,0,0,0.15);
}

.tier-card.tier-1 { border-color: #1E5C99; }
.tier-card.tier-2 { border-color: #0F3057; }
.tier-card.tier-3 { border-color: #FFB400; }
.tier-card.tier-max { border-color: #FFD700; }

.tier-icon {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 20px;
    font-size: 2.5rem;
    color: white;
}

.tier-1 .tier-icon { background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%); }
.tier-2 .tier-icon { background: linear-gradient(135deg, #0F3057 0%, #1E5C99 100%); }
.tier-3 .tier-icon { background: linear-gradient(135deg, #FFB400 0%, #FFD700 100%); }
.tier-max .tier-icon { background: linear-gradient(135deg, #FFD700 0%, #FFB400 100%); }

.tier-name {
    font-size: 1.5rem;
    font-weight: 800;
    color: #1E5C99;
    margin-bottom: 10px;
}

.tier-requirement {
    color: #999;
    font-size: 0.95rem;
    margin-bottom: 20px;
}

.tier-commission {
    font-size: 2.5rem;
    font-weight: 900;
    color: #FFB400;
    margin-bottom: 20px;
}

.tier-features {
    list-style: none;
    padding: 0;
    margin: 0;
}

.tier-features li {
    padding: 8px 0;
    color: #666;
    font-size: 0.95rem;
}

/* FAQ Pricing */
.pricing-faq {
    padding: 80px 0;
    background: #f8f9fa;
}

.faq-item {
    background: white;
    border-radius: 16px;
    margin-bottom: 20px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    overflow: hidden;
}

.faq-question {
    padding: 25px 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    cursor: pointer;
    transition: all 0.3s ease;
}

.faq-question:hover {
    background: #f8f9fa;
}

.faq-question h4 {
    color: #1E5C99;
    font-weight: 700;
    margin: 0;
    font-size: 1.1rem;
}

.faq-icon {
    color: #FFB400;
    font-size: 1.5rem;
    transition: transform 0.3s ease;
}

.faq-item.active .faq-icon {
    transform: rotate(45deg);
}

.faq-answer {
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.3s ease;
}

.faq-item.active .faq-answer {
    max-height: 500px;
}

.faq-answer-content {
    padding: 0 30px 25px 30px;
    color: #666;
    line-height: 1.8;
}

/* Responsive */
@media (max-width: 768px) {
    .pricing-header h1 {
        font-size: 2rem;
    }
    
    .pricing-card {
        margin-bottom: 30px;
    }
    
    .pricing-card.featured {
        transform: scale(1);
    }
    
    .package-list {
        grid-template-columns: 1fr;
    }
}
</style>

<!-- Header Section -->
<section class="pricing-header">
    <div class="container">
        <div class="pricing-header-content">
            <h1>Harga & Paket</h1>
            <p>Pilih paket yang sesuai dengan kebutuhan bisnis Anda</p>
        </div>
    </div>
</section>

<!-- Main Pricing Cards -->
<section class="main-pricing">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">Paket Website Populer</h2>
            <p class="section-subtitle text-muted">Harga terjangkau dengan kualitas premium</p>
        </div>
        
        <div class="row">
            <!-- Basic Package -->
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="pricing-card">
                    <div class="pricing-icon">
                        <i class="fas fa-rocket"></i>
                    </div>
                    <h3 class="pricing-title">Starter</h3>
                    <p class="pricing-subtitle">Perfect untuk bisnis baru</p>
                    <div class="pricing-price">
                        <div class="price-amount">Rp 150rb</div>
                        <div class="price-period">/bulan</div>
                    </div>
                    <ul class="pricing-features">
                        <li><i class="fas fa-check-circle"></i> 5 Halaman Website</li>
                        <li><i class="fas fa-check-circle"></i> Responsive Design</li>
                        <li><i class="fas fa-check-circle"></i> FREE Domain (.my.id)</li>
                        <li><i class="fas fa-check-circle"></i> FREE SSL Certificate</li>
                        <li><i class="fas fa-check-circle"></i> FREE Hosting 1GB</li>
                        <li><i class="fas fa-check-circle"></i> WhatsApp Integration</li>
                        <li><i class="fas fa-check-circle"></i> Basic SEO</li>
                        <li><i class="fas fa-check-circle"></i> Support 24/7</li>
                    </ul>
                    <a href="<?php echo whatsappUrl('Halo! Saya mau pesan paket Starter Rp 150rb/bulan'); ?>" 
                       class="pricing-cta" target="_blank">
                        <i class="fab fa-whatsapp"></i> Pesan Sekarang
                    </a>
                </div>
            </div>
            
            <!-- Standard Package (Featured) -->
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="pricing-card featured">
                    <span class="pricing-badge">Paling Populer</span>
                    <div class="pricing-icon">
                        <i class="fas fa-star"></i>
                    </div>
                    <h3 class="pricing-title">Professional</h3>
                    <p class="pricing-subtitle">Untuk bisnis berkembang</p>
                    <div class="pricing-price">
                        <div class="price-amount">Rp 350rb</div>
                        <div class="price-period">/bulan</div>
                    </div>
                    <ul class="pricing-features">
                        <li><i class="fas fa-check-circle"></i> 10 Halaman Website</li>
                        <li><i class="fas fa-check-circle"></i> Premium Design</li>
                        <li><i class="fas fa-check-circle"></i> FREE Domain (.com/.id)</li>
                        <li><i class="fas fa-check-circle"></i> FREE SSL Certificate</li>
                        <li><i class="fas fa-check-circle"></i> FREE Hosting 5GB</li>
                        <li><i class="fas fa-check-circle"></i> Admin Panel</li>
                        <li><i class="fas fa-check-circle"></i> Advanced SEO</li>
                        <li><i class="fas fa-check-circle"></i> Email Professional</li>
                        <li><i class="fas fa-check-circle"></i> Priority Support</li>
                    </ul>
                    <a href="<?php echo whatsappUrl('Halo! Saya mau pesan paket Professional Rp 350rb/bulan'); ?>" 
                       class="pricing-cta" target="_blank">
                        <i class="fab fa-whatsapp"></i> Pesan Sekarang
                    </a>
                </div>
            </div>
            
            <!-- Premium Package -->
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="pricing-card">
                    <div class="pricing-icon">
                        <i class="fas fa-crown"></i>
                    </div>
                    <h3 class="pricing-title">Enterprise</h3>
                    <p class="pricing-subtitle">Solusi lengkap untuk perusahaan</p>
                    <div class="pricing-price">
                        <div class="price-amount">Rp 750rb</div>
                        <div class="price-period">/bulan</div>
                    </div>
                    <ul class="pricing-features">
                        <li><i class="fas fa-check-circle"></i> Unlimited Halaman</li>
                        <li><i class="fas fa-check-circle"></i> Custom Design</li>
                        <li><i class="fas fa-check-circle"></i> FREE Domain Premium</li>
                        <li><i class="fas fa-check-circle"></i> FREE SSL Certificate</li>
                        <li><i class="fas fa-check-circle"></i> FREE Hosting 20GB</li>
                        <li><i class="fas fa-check-circle"></i> Advanced Admin Panel</li>
                        <li><i class="fas fa-check-circle"></i> Premium SEO</li>
                        <li><i class="fas fa-check-circle"></i> Email Professional</li>
                        <li><i class="fas fa-check-circle"></i> Mobile App Integration</li>
                        <li><i class="fas fa-check-circle"></i> VIP Support 24/7</li>
                    </ul>
                    <a href="<?php echo whatsappUrl('Halo! Saya mau pesan paket Enterprise Rp 750rb/bulan'); ?>" 
                       class="pricing-cta" target="_blank">
                        <i class="fab fa-whatsapp"></i> Pesan Sekarang
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Services Pricing -->
<section class="services-pricing">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">Layanan Lainnya</h2>
            <p class="section-subtitle text-muted">Pilihan lengkap untuk semua kebutuhan digital Anda</p>
        </div>
        
        <?php if (!empty($featuredServices)): ?>
            <?php foreach ($featuredServices as $service): ?>
                <?php
                $packages = getServicePackages($service['id']);
                $category = $db->fetchOne("SELECT name FROM service_categories WHERE id = ?", [$service['category_id']]);
                ?>
                <div class="service-pricing-card">
                    <div class="service-pricing-header">
                        <div class="service-pricing-info">
                            <h3><?php echo htmlspecialchars($service['name']); ?></h3>
                            <span class="category"><?php echo htmlspecialchars($category['name'] ?? 'Layanan'); ?></span>
                        </div>
                        <div class="service-pricing-price">
                            <div class="price-label">Mulai dari</div>
                            <div class="price-value"><?php echo formatRupiahShort($service['starting_price']); ?></div>
                        </div>
                    </div>
                    
                    <p class="service-pricing-desc">
                        <?php echo htmlspecialchars(substr($service['description'], 0, 150)) . '...'; ?>
                    </p>
                    
                    <?php if (!empty($packages)): ?>
                        <div class="package-list">
                            <?php foreach ($packages as $package): ?>
                                <div class="package-item">
                                    <div class="package-name"><?php echo htmlspecialchars($package['name']); ?></div>
                                    <div class="package-price"><?php echo formatRupiahShort($package['price']); ?></div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    
                    <div class="service-pricing-cta">
                        <a href="/calculator.php?service=<?php echo $service['id']; ?>" class="btn btn-outline-primary">
                            <i class="fas fa-calculator"></i> Hitung Harga
                        </a>
                        <a href="<?php echo whatsappUrl('Halo! Saya tertarik dengan: ' . $service['name']); ?>" 
                           class="btn btn-primary" target="_blank">
                            <i class="fab fa-whatsapp"></i> Pesan Sekarang
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</section>

<!-- Tier System for Freelancers -->
<section class="tier-system">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">Tier System untuk Partner</h2>
            <p class="section-subtitle text-muted">Dapatkan komisi hingga 55% dengan tier system kami</p>
        </div>
        
        <div class="tier-grid">
            <div class="tier-card tier-1">
                <div class="tier-icon">
                    <i class="<?php echo TIER_1_ICON; ?>"></i>
                </div>
                <h3 class="tier-name">Tier 1 - Starter</h3>
                <p class="tier-requirement">0-10 order/bulan</p>
                <div class="tier-commission">30%</div>
                <ul class="tier-features">
                    <li>Komisi 30% per order</li>
                    <li>Dashboard akses</li>
                    <li>Penarikan mingguan</li>
                    <li>Support team</li>
                </ul>
            </div>
            
            <div class="tier-card tier-2">
                <div class="tier-icon">
                    <i class="<?php echo TIER_2_ICON; ?>"></i>
                </div>
                <h3 class="tier-name">Tier 2 - Professional</h3>
                <p class="tier-requirement">10-25 order/bulan</p>
                <div class="tier-commission">40%</div>
                <ul class="tier-features">
                    <li>Komisi 40% per order</li>
                    <li>Priority dashboard</li>
                    <li>Penarikan harian</li>
                    <li>Priority support</li>
                </ul>
            </div>
            
            <div class="tier-card tier-3">
                <div class="tier-icon">
                    <i class="<?php echo TIER_3_ICON; ?>"></i>
                </div>
                <h3 class="tier-name">Tier 3 - Expert</h3>
                <p class="tier-requirement">25-75 order/bulan</p>
                <div class="tier-commission">50%</div>
                <ul class="tier-features">
                    <li>Komisi 50% per order</li>
                    <li>Advanced dashboard</li>
                    <li>Instant withdrawal</li>
                    <li>Dedicated support</li>
                </ul>
            </div>
            
            <div class="tier-card tier-max">
                <div class="tier-icon">
                    <i class="<?php echo TIER_MAX_ICON; ?>"></i>
                </div>
                <h3 class="tier-name">Tier MAX - Elite</h3>
                <p class="tier-requirement">75+ order/bulan</p>
                <div class="tier-commission">55%</div>
                <ul class="tier-features">
                    <li>Komisi 55% per order</li>
                    <li>Bonus 5% ekstra</li>
                    <li>VIP dashboard</li>
                    <li>Instant withdrawal</li>
                    <li>VIP support 24/7</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<!-- FAQ Section -->
<section class="pricing-faq">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">Pertanyaan Seputar Harga</h2>
            <p class="section-subtitle text-muted">Jawaban untuk pertanyaan yang sering ditanyakan</p>
        </div>
        
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <div class="faq-item">
                    <div class="faq-question" onclick="toggleFaq(this)">
                        <h4>Apakah ada biaya setup atau biaya tersembunyi?</h4>
                        <i class="fas fa-plus faq-icon"></i>
                    </div>
                    <div class="faq-answer">
                        <div class="faq-answer-content">
                            Tidak ada biaya tersembunyi! Harga yang tertera sudah termasuk setup, domain, hosting, dan SSL. 
                            Anda hanya bayar sesuai paket yang dipilih.
                        </div>
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question" onclick="toggleFaq(this)">
                        <h4>Bagaimana sistem pembayarannya?</h4>
                        <i class="fas fa-plus faq-icon"></i>
                    </div>
                    <div class="faq-answer">
                        <div class="faq-answer-content">
                            Pembayaran dilakukan bulanan. Anda bisa membayar via transfer bank (BCA), QRIS, GoPay, OVO, atau DANA. 
                            Invoice akan dikirim setiap bulan via email.
                        </div>
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question" onclick="toggleFaq(this)">
                        <h4>Apakah bisa upgrade atau downgrade paket?</h4>
                        <i class="fas fa-plus faq-icon"></i>
                    </div>
                    <div class="faq-answer">
                        <div class="faq-answer-content">
                            Tentu saja! Anda bisa upgrade atau downgrade paket kapan saja. Biaya akan disesuaikan dengan 
                            paket baru mulai periode berikutnya.
                        </div>
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question" onclick="toggleFaq(this)">
                        <h4>Apakah ada garansi uang kembali?</h4>
                        <i class="fas fa-plus faq-icon"></i>
                    </div>
                    <div class="faq-answer">
                        <div class="faq-answer-content">
                            Ya! Kami memberikan garansi 100% uang kembali dalam 30 hari pertama jika Anda tidak puas 
                            dengan layanan kami. No questions asked!
                        </div>
                    </div>
                </div>
                
                <div class="faq-item">
                    <div class="faq-question" onclick="toggleFaq(this)">
                        <h4>Berapa lama waktu pengerjaan?</h4>
                        <i class="fas fa-plus faq-icon"></i>
                    </div>
                    <div class="faq-answer">
                        <div class="faq-answer-content">
                            Paket Starter: 3-5 hari, Professional: 7-10 hari, Enterprise: 14-21 hari. 
                            Anda akan mendapat demo 24 jam setelah konfirmasi pembayaran!
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="section bg-gradient-primary text-white text-center">
    <div class="container">
        <h2 class="mb-3">Siap Memulai Project Anda?</h2>
        <p class="mb-4">Dapatkan demo GRATIS dalam 24 jam dan konsultasi tanpa biaya</p>
        <div class="d-flex justify-content-center gap-3 flex-wrap">
            <a href="/calculator.php" class="btn btn-gold btn-lg">
                <i class="fas fa-calculator"></i> Hitung Harga Project
            </a>
            <a href="<?php echo whatsappUrl('Halo! Saya mau konsultasi FREE dan lihat demo 24 jam'); ?>" 
               class="btn btn-outline-white btn-lg" target="_blank">
                <i class="fab fa-whatsapp"></i> Konsultasi Gratis
            </a>
        </div>
    </div>
</section>

<script>
function toggleFaq(element) {
    const faqItem = element.closest('.faq-item');
    const allFaqs = document.querySelectorAll('.faq-item');
    
    // Close all other FAQs
    allFaqs.forEach(item => {
        if (item !== faqItem) {
            item.classList.remove('active');
        }
    });
    
    // Toggle current FAQ
    faqItem.classList.toggle('active');
}
</script>

<?php include __DIR__ . '/components/layout/footer.php'; ?>

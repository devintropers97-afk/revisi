<?php
/**
 * SITUNEO DIGITAL - Services Page
 * Katalog layanan lengkap dengan filters, search, dan detail paket
 */

require_once __DIR__ . '/includes/init.php';

// Page config
$currentPage = 'services';
$pageTitle = 'Layanan Kami';
$pageDescription = 'Katalog lengkap layanan digital SITUNEO DIGITAL. Website, Mobile App, Digital Marketing, SEO, dan lebih banyak lagi dengan harga terjangkau.';
$pageKeywords = 'jasa website, mobile app, digital marketing, seo services, web development';

// Get filters
$categoryId = isset($_GET['category']) ? (int)$_GET['category'] : 0;
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'popular';

// Get categories
$categories = getServiceCategories();

// Build filters
$filters = ['is_active' => 1];
if ($categoryId > 0) {
    $filters['category_id'] = $categoryId;
}

// Get services
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$perPage = 12;

if (!empty($search)) {
    $services = searchServices($search, $filters);
} else {
    $services = getServices($filters, $page, $perPage);
}

// Sort services
if ($sort === 'price_low') {
    usort($services, function($a, $b) {
        return $a['starting_price'] - $b['starting_price'];
    });
} elseif ($sort === 'price_high') {
    usort($services, function($a, $b) {
        return $b['starting_price'] - $a['starting_price'];
    });
} elseif ($sort === 'name') {
    usort($services, function($a, $b) {
        return strcmp($a['name'], $b['name']);
    });
}

// Include header
include __DIR__ . '/components/layout/header.php';
?>

<style>
/* Services Page Styles */
.services-header {
    background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%);
    padding: 100px 0 60px;
    position: relative;
    overflow: hidden;
}

.services-header::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: url('data:image/svg+xml,<svg width="100" height="100" xmlns="http://www.w3.org/2000/svg"><circle cx="50" cy="50" r="40" fill="none" stroke="rgba(255,255,255,0.03)" stroke-width="2"/></svg>');
    background-size: 100px 100px;
}

.services-header-content {
    position: relative;
    z-index: 2;
    text-align: center;
    color: white;
}

.services-header h1 {
    font-size: 2.8rem;
    font-weight: 800;
    margin-bottom: 1rem;
    background: linear-gradient(135deg, #FFB400 0%, #FFD700 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.services-header p {
    font-size: 1.2rem;
    opacity: 0.9;
}

/* Search & Filters */
.services-filters {
    background: white;
    padding: 30px 0;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    position: sticky;
    top: 0;
    z-index: 100;
}

.search-box {
    position: relative;
    max-width: 500px;
    margin: 0 auto 20px;
}

.search-box input {
    width: 100%;
    padding: 15px 50px 15px 20px;
    border: 2px solid #e0e0e0;
    border-radius: 50px;
    font-size: 1rem;
    transition: all 0.3s ease;
}

.search-box input:focus {
    border-color: #1E5C99;
    outline: none;
    box-shadow: 0 0 0 4px rgba(30, 92, 153, 0.1);
}

.search-box button {
    position: absolute;
    right: 5px;
    top: 50%;
    transform: translateY(-50%);
    background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%);
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 50px;
    cursor: pointer;
    transition: all 0.3s ease;
}

.search-box button:hover {
    background: linear-gradient(135deg, #0F3057 0%, #1E5C99 100%);
}

.filter-buttons {
    display: flex;
    justify-content: center;
    gap: 10px;
    flex-wrap: wrap;
    margin-bottom: 15px;
}

.filter-btn {
    padding: 10px 20px;
    border: 2px solid #e0e0e0;
    background: white;
    border-radius: 50px;
    cursor: pointer;
    transition: all 0.3s ease;
    font-weight: 600;
    color: #666;
}

.filter-btn:hover, .filter-btn.active {
    background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%);
    color: white;
    border-color: #1E5C99;
}

.sort-dropdown {
    text-align: center;
}

.sort-dropdown select {
    padding: 10px 40px 10px 20px;
    border: 2px solid #e0e0e0;
    border-radius: 50px;
    font-size: 0.95rem;
    background: white;
    cursor: pointer;
    transition: all 0.3s ease;
}

.sort-dropdown select:focus {
    border-color: #1E5C99;
    outline: none;
}

/* Services Grid */
.services-grid {
    padding: 60px 0;
}

.service-card {
    background: white;
    border-radius: 20px;
    overflow: hidden;
    box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    transition: all 0.3s ease;
    margin-bottom: 30px;
    height: 100%;
    display: flex;
    flex-direction: column;
}

.service-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 10px 40px rgba(0,0,0,0.15);
}

.service-image {
    position: relative;
    padding-top: 60%;
    overflow: hidden;
}

.service-image img {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s ease;
}

.service-card:hover .service-image img {
    transform: scale(1.1);
}

.service-badge {
    position: absolute;
    top: 15px;
    left: 15px;
    background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%);
    color: white;
    padding: 6px 15px;
    border-radius: 50px;
    font-size: 0.85rem;
    font-weight: 600;
}

.service-featured {
    position: absolute;
    top: 15px;
    right: 15px;
    background: linear-gradient(135deg, #FFB400 0%, #FFD700 100%);
    color: white;
    padding: 6px 12px;
    border-radius: 50px;
    font-size: 0.85rem;
    font-weight: 600;
}

.service-content {
    padding: 25px;
    flex-grow: 1;
    display: flex;
    flex-direction: column;
}

.service-content h3 {
    color: #1E5C99;
    font-size: 1.4rem;
    font-weight: 700;
    margin-bottom: 12px;
}

.service-content p {
    color: #666;
    line-height: 1.7;
    margin-bottom: 20px;
    flex-grow: 1;
}

.service-features {
    list-style: none;
    padding: 0;
    margin: 0 0 20px 0;
}

.service-features li {
    padding: 6px 0;
    color: #555;
    font-size: 0.95rem;
}

.service-features li i {
    color: #FFB400;
    margin-right: 8px;
}

.service-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding-top: 20px;
    border-top: 1px solid #e0e0e0;
}

.service-price {
    display: flex;
    flex-direction: column;
}

.price-label {
    font-size: 0.85rem;
    color: #999;
}

.price-value {
    font-size: 1.6rem;
    font-weight: 800;
    color: #1E5C99;
}

.service-cta {
    background: linear-gradient(135deg, #FFB400 0%, #FFD700 100%);
    color: white;
    padding: 12px 24px;
    border-radius: 50px;
    text-decoration: none;
    font-weight: 600;
    transition: all 0.3s ease;
    border: none;
    cursor: pointer;
}

.service-cta:hover {
    background: linear-gradient(135deg, #FFD700 0%, #FFB400 100%);
    transform: scale(1.05);
    color: white;
}

/* Empty State */
.empty-state {
    text-align: center;
    padding: 80px 20px;
}

.empty-state i {
    font-size: 5rem;
    color: #ddd;
    margin-bottom: 20px;
}

.empty-state h3 {
    color: #666;
    margin-bottom: 10px;
}

.empty-state p {
    color: #999;
}

/* Pagination */
.pagination {
    display: flex;
    justify-content: center;
    gap: 10px;
    margin-top: 40px;
}

.pagination a, .pagination span {
    padding: 10px 18px;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    color: #666;
    text-decoration: none;
    transition: all 0.3s ease;
}

.pagination a:hover, .pagination span.active {
    background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%);
    color: white;
    border-color: #1E5C99;
}

/* Responsive */
@media (max-width: 768px) {
    .services-header h1 {
        font-size: 2rem;
    }
    
    .filter-buttons {
        gap: 5px;
    }
    
    .filter-btn {
        padding: 8px 15px;
        font-size: 0.9rem;
    }
}
</style>

<!-- Header Section -->
<section class="services-header">
    <div class="container">
        <div class="services-header-content">
            <h1>Layanan Kami</h1>
            <p>Solusi digital lengkap untuk semua kebutuhan bisnis Anda</p>
        </div>
    </div>
</section>

<!-- Filters Section -->
<section class="services-filters">
    <div class="container">
        <!-- Search Box -->
        <form method="GET" action="/services.php" class="search-box">
            <input type="text" name="search" placeholder="Cari layanan..." 
                   value="<?php echo htmlspecialchars($search); ?>">
            <button type="submit">
                <i class="fas fa-search"></i>
            </button>
        </form>
        
        <!-- Category Filters -->
        <div class="filter-buttons">
            <a href="/services.php" class="filter-btn <?php echo $categoryId === 0 ? 'active' : ''; ?>">
                Semua Layanan
            </a>
            <?php foreach ($categories as $cat): ?>
                <a href="/services.php?category=<?php echo $cat['id']; ?>" 
                   class="filter-btn <?php echo $categoryId === $cat['id'] ? 'active' : ''; ?>">
                    <?php echo htmlspecialchars($cat['name']); ?>
                </a>
            <?php endforeach; ?>
        </div>
        
        <!-- Sort Options -->
        <div class="sort-dropdown">
            <select name="sort" onchange="window.location.href='/services.php?sort=' + this.value + '<?php echo $categoryId > 0 ? '&category=' . $categoryId : ''; ?>'">
                <option value="popular" <?php echo $sort === 'popular' ? 'selected' : ''; ?>>Paling Populer</option>
                <option value="price_low" <?php echo $sort === 'price_low' ? 'selected' : ''; ?>>Harga Terendah</option>
                <option value="price_high" <?php echo $sort === 'price_high' ? 'selected' : ''; ?>>Harga Tertinggi</option>
                <option value="name" <?php echo $sort === 'name' ? 'selected' : ''; ?>>Nama A-Z</option>
            </select>
        </div>
    </div>
</section>

<!-- Services Grid -->
<section class="services-grid">
    <div class="container">
        <?php if (empty($services)): ?>
            <!-- Empty State -->
            <div class="empty-state">
                <i class="fas fa-search"></i>
                <h3>Tidak Ada Layanan Ditemukan</h3>
                <p>Coba gunakan kata kunci lain atau filter berbeda</p>
                <a href="/services.php" class="btn btn-primary mt-3">
                    <i class="fas fa-arrow-left"></i> Kembali ke Semua Layanan
                </a>
            </div>
        <?php else: ?>
            <div class="row">
                <?php foreach ($services as $service): ?>
                    <?php
                    // Get category name
                    $category = $db->fetchOne("SELECT name FROM service_categories WHERE id = ?", [$service['category_id']]);
                    
                    // Get packages for this service
                    $packages = getServicePackages($service['id']);
                    $startingPrice = $service['starting_price'];
                    
                    // Generate image URL
                    $imageUrl = !empty($service['image']) 
                        ? $service['image'] 
                        : 'https://source.unsplash.com/800x600/?' . urlencode($service['name']);
                    ?>
                    
                    <div class="col-lg-4 col-md-6">
                        <div class="service-card">
                            <div class="service-image">
                                <img src="<?php echo $imageUrl; ?>" 
                                     alt="<?php echo htmlspecialchars($service['name']); ?>">
                                <span class="service-badge">
                                    <?php echo htmlspecialchars($category['name'] ?? 'Layanan'); ?>
                                </span>
                                <?php if ($service['is_featured']): ?>
                                    <span class="service-featured">
                                        <i class="fas fa-star"></i> Featured
                                    </span>
                                <?php endif; ?>
                            </div>
                            
                            <div class="service-content">
                                <h3><?php echo htmlspecialchars($service['name']); ?></h3>
                                <p><?php echo htmlspecialchars(substr($service['description'], 0, 120)) . '...'; ?></p>
                                
                                <?php if (!empty($service['features'])): ?>
                                    <?php $features = json_decode($service['features'], true); ?>
                                    <?php if (is_array($features) && count($features) > 0): ?>
                                        <ul class="service-features">
                                            <?php foreach (array_slice($features, 0, 3) as $feature): ?>
                                                <li>
                                                    <i class="fas fa-check-circle"></i>
                                                    <?php echo htmlspecialchars($feature); ?>
                                                </li>
                                            <?php endforeach; ?>
                                        </ul>
                                    <?php endif; ?>
                                <?php endif; ?>
                                
                                <div class="service-footer">
                                    <div class="service-price">
                                        <span class="price-label">Mulai dari</span>
                                        <span class="price-value"><?php echo formatRupiahShort($startingPrice); ?></span>
                                    </div>
                                    <a href="<?php echo whatsappUrl('Halo! Saya tertarik dengan layanan: ' . $service['name']); ?>" 
                                       class="service-cta" target="_blank">
                                        <i class="fab fa-whatsapp"></i> Pesan
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <!-- Pagination (placeholder - implement if needed) -->
            <?php if (count($services) >= $perPage): ?>
                <div class="pagination">
                    <a href="?page=<?php echo max(1, $page - 1); ?>">
                        <i class="fas fa-chevron-left"></i>
                    </a>
                    <span class="active"><?php echo $page; ?></span>
                    <a href="?page=<?php echo $page + 1; ?>">
                        <i class="fas fa-chevron-right"></i>
                    </a>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</section>

<!-- CTA Section -->
<section class="section bg-gradient-primary text-white text-center">
    <div class="container">
        <h2 class="mb-3">Tidak Menemukan Layanan Yang Anda Cari?</h2>
        <p class="mb-4">Hubungi kami untuk konsultasi gratis dan dapatkan solusi custom sesuai kebutuhan bisnis Anda</p>
        <a href="<?php echo whatsappUrl('Halo! Saya ingin konsultasi tentang layanan custom'); ?>" 
           class="btn btn-gold btn-lg" target="_blank">
            <i class="fab fa-whatsapp"></i> Konsultasi Gratis Sekarang
        </a>
    </div>
</section>

<?php include __DIR__ . '/components/layout/footer.php'; ?>

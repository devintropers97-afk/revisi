<?php
/**
 * Test Homepage Data
 * Cek apakah data dari database bisa di-pull dengan benar
 */

require_once 'includes/init.php';

// Use global database instance
global $db;

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Homepage Data - SITUNEO</title>
    <style>
        body {
            font-family: 'Inter', sans-serif;
            max-width: 1200px;
            margin: 40px auto;
            padding: 20px;
            background: #f5f5f5;
        }
        .test-section {
            background: white;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .test-section h2 {
            color: #1E5C99;
            margin-top: 0;
            padding-bottom: 10px;
            border-bottom: 2px solid #FFB400;
        }
        .pass { color: #28a745; font-weight: bold; }
        .fail { color: #dc3545; font-weight: bold; }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background: #f8f9fa;
            font-weight: 600;
        }
        .summary {
            background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%);
            color: white;
            padding: 30px;
            border-radius: 8px;
            text-align: center;
        }
        .summary h1 {
            margin: 0 0 20px 0;
        }
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .stat-item {
            background: rgba(255,255,255,0.1);
            padding: 15px;
            border-radius: 8px;
            text-align: center;
        }
        .stat-item h3 {
            margin: 0;
            font-size: 32px;
        }
        .stat-item p {
            margin: 5px 0 0 0;
            opacity: 0.9;
        }
    </style>
</head>
<body>
    <div class="summary">
        <h1>🔧 SITUNEO Homepage Data Test</h1>
        <p>Testing data integration dari BATCH 1, 2, & 3</p>
    </div>

    <?php
    $allPass = true;
    $totalTests = 0;
    $passedTests = 0;

    // TEST 1: Database Connection
    echo '<div class="test-section">';
    echo '<h2>1️⃣ Database Connection</h2>';
    $totalTests++;
    
    try {
        if ($db && $db->isConnected()) {
            echo '<p class="pass">✅ Database Connection: SUCCESS</p>';
            echo '<p>Database: nrrskfvk_situneo_digital</p>';
            $passedTests++;
        } else {
            echo '<p class="fail">❌ Database Connection: FAILED</p>';
            $allPass = false;
        }
    } catch (Exception $e) {
        echo '<p class="fail">❌ Database Connection: ERROR</p>';
        echo '<p>Error: ' . $e->getMessage() . '</p>';
        $allPass = false;
    }
    echo '</div>';

    // TEST 2: Services
    echo '<div class="test-section">';
    echo '<h2>2️⃣ Services Data</h2>';
    $totalTests++;
    
    try {
        $services = $db->query("SELECT s.*, sc.name as category_name FROM services s LEFT JOIN service_categories sc ON s.category_id = sc.id WHERE s.is_active = 1 ORDER BY s.display_order ASC LIMIT 6");
        $serviceCount = $services ? $services->num_rows : 0;
        
        if ($serviceCount > 0) {
            echo '<p class="pass">✅ Services: ' . $serviceCount . ' active services found</p>';
            echo '<table>';
            echo '<tr><th>Service Name</th><th>Category</th><th>Price</th><th>Type</th></tr>';
            
            while ($service = $services->fetch_assoc()) {
                echo '<tr>';
                echo '<td>' . htmlspecialchars($service['name']) . '</td>';
                echo '<td>' . htmlspecialchars($service['category_name'] ?? 'N/A') . '</td>';
                echo '<td>' . formatRupiah($service['price']) . '</td>';
                echo '<td>' . ($service['price_type'] == 'one_time' ? 'One-time' : 'Monthly') . '</td>';
                echo '</tr>';
            }
            echo '</table>';
            $passedTests++;
        } else {
            echo '<p class="fail">❌ No services found in database</p>';
            echo '<p>⚠️ Run database seeder to add sample data</p>';
            $passedTests++; // Not critical
        }
    } catch (Exception $e) {
        echo '<p class="fail">❌ Services Query: ERROR</p>';
        echo '<p>Error: ' . $e->getMessage() . '</p>';
        $allPass = false;
    }
    echo '</div>';

    // TEST 3: Portfolio
    echo '<div class="test-section">';
    echo '<h2>3️⃣ Portfolio Data</h2>';
    $totalTests++;
    
    try {
        $portfolio = $db->query("SELECT * FROM portfolios WHERE is_featured = 1 ORDER BY display_order ASC LIMIT 6");
        $portfolioCount = $portfolio ? $portfolio->num_rows : 0;
        
        if ($portfolioCount > 0) {
            echo '<p class="pass">✅ Portfolio: ' . $portfolioCount . ' featured projects found</p>';
            $passedTests++;
        } else {
            echo '<p class="fail">⚠️ No portfolio items found (not critical)</p>';
            $passedTests++; // Not critical
        }
    } catch (Exception $e) {
        echo '<p class="fail">❌ Portfolio Query: ERROR</p>';
        echo '<p>Error: ' . $e->getMessage() . '</p>';
        $allPass = false;
    }
    echo '</div>';

    // TEST 4: Testimonials
    echo '<div class="test-section">';
    echo '<h2>4️⃣ Testimonials Data</h2>';
    $totalTests++;
    
    try {
        $testimonials = $db->query("SELECT * FROM testimonials WHERE is_active = 1 ORDER BY display_order ASC LIMIT 6");
        $testimonialsCount = $testimonials ? $testimonials->num_rows : 0;
        
        if ($testimonialsCount > 0) {
            echo '<p class="pass">✅ Testimonials: ' . $testimonialsCount . ' reviews found</p>';
            $passedTests++;
        } else {
            echo '<p class="fail">⚠️ No testimonials found (not critical)</p>';
            $passedTests++; // Not critical
        }
    } catch (Exception $e) {
        echo '<p class="fail">❌ Testimonials Query: ERROR</p>';
        echo '<p>Error: ' . $e->getMessage() . '</p>';
        $allPass = false;
    }
    echo '</div>';

    // TEST 5: Helper Functions
    echo '<div class="test-section">';
    echo '<h2>5️⃣ Helper Functions</h2>';
    $totalTests++;
    
    try {
        $tests = [
            'formatRupiah(1500000)' => formatRupiah(1500000),
            'formatDate("2025-10-30")' => formatDate('2025-10-30'),
            'formatPhone("08123456789")' => formatPhone('08123456789')
        ];
        
        echo '<table>';
        echo '<tr><th>Function</th><th>Result</th></tr>';
        $allFunctionsWork = true;
        
        foreach ($tests as $func => $result) {
            echo '<tr>';
            echo '<td><code>' . htmlspecialchars($func) . '</code></td>';
            echo '<td>' . htmlspecialchars($result) . '</td>';
            echo '</tr>';
            
            if (empty($result)) {
                $allFunctionsWork = false;
            }
        }
        echo '</table>';
        
        if ($allFunctionsWork) {
            echo '<p class="pass">✅ All helper functions working</p>';
            $passedTests++;
        } else {
            echo '<p class="fail">❌ Some helper functions not working</p>';
            $allPass = false;
        }
    } catch (Exception $e) {
        echo '<p class="fail">❌ Helper Functions: ERROR</p>';
        echo '<p>Error: ' . $e->getMessage() . '</p>';
        $allPass = false;
    }
    echo '</div>';

    // TEST 6: Service Functions (NEW)
    echo '<div class="test-section">';
    echo '<h2>6️⃣ Service Functions</h2>';
    $totalTests++;
    
    $serviceFunctions = [
        'getServices',
        'getFeaturedServices',
        'getServiceById'
    ];
    
    $functionsExist = true;
    foreach ($serviceFunctions as $func) {
        if (!function_exists($func)) {
            echo '<p class="fail">❌ Function ' . $func . '() not found</p>';
            $functionsExist = false;
        }
    }
    
    if ($functionsExist) {
        echo '<p class="pass">✅ All service functions available</p>';
        $passedTests++;
    } else {
        echo '<p class="fail">⚠️ Service functions not loaded</p>';
        echo '<p>Fix: Add service files to init.php</p>';
        $allPass = false;
    }
    echo '</div>';

    // TEST 7: Constants
    echo '<div class="test-section">';
    echo '<h2>7️⃣ Constants Configuration</h2>';
    $totalTests++;
    
    try {
        $constants = [
            'COMPANY_NAME' => defined('COMPANY_NAME') ? COMPANY_NAME : 'NOT DEFINED',
            'COMPANY_NIB' => defined('COMPANY_NIB') ? COMPANY_NIB : 'NOT DEFINED',
            'CONTACT_WHATSAPP' => defined('CONTACT_WHATSAPP') ? CONTACT_WHATSAPP : 'NOT DEFINED',
        ];
        
        echo '<table>';
        echo '<tr><th>Constant</th><th>Value</th></tr>';
        $allDefined = true;
        
        foreach ($constants as $name => $value) {
            echo '<tr>';
            echo '<td><code>' . htmlspecialchars($name) . '</code></td>';
            echo '<td>' . htmlspecialchars($value) . '</td>';
            echo '</tr>';
            
            if ($value === 'NOT DEFINED') {
                $allDefined = false;
            }
        }
        echo '</table>';
        
        if ($allDefined) {
            echo '<p class="pass">✅ All constants defined</p>';
            $passedTests++;
        } else {
            echo '<p class="fail">❌ Some constants not defined</p>';
            $allPass = false;
        }
    } catch (Exception $e) {
        echo '<p class="fail">❌ Constants: ERROR</p>';
        echo '<p>Error: ' . $e->getMessage() . '</p>';
        $allPass = false;
    }
    echo '</div>';

    // FINAL SUMMARY
    echo '<div class="test-section summary">';
    echo '<h1>' . ($passedTests >= 6 ? '🎉 TESTS PASSED!' : '⚠️ SOME TESTS FAILED') . '</h1>';
    echo '<div class="stats">';
    echo '<div class="stat-item">';
    echo '<h3>' . $passedTests . '/' . $totalTests . '</h3>';
    echo '<p>Tests Passed</p>';
    echo '</div>';
    echo '<div class="stat-item">';
    echo '<h3>' . round(($passedTests / $totalTests) * 100) . '%</h3>';
    echo '<p>Success Rate</p>';
    echo '</div>';
    echo '</div>';
    
    if ($passedTests >= 6) {
        echo '<p style="margin-top: 30px; font-size: 18px;">✅ <strong>SYSTEM READY!</strong> Core functions working.</p>';
        echo '<p><a href="/" style="color: #FFD700; text-decoration: none; font-weight: bold;">➜ Test Homepage</a></p>';
    } else {
        echo '<p style="margin-top: 30px;">⚠️ Some critical tests failed. Please fix before continuing.</p>';
    }
    echo '</div>';
    ?>

    <div style="text-align: center; margin-top: 40px; padding: 20px; background: white; border-radius: 8px;">
        <p style="color: #666; margin: 0;">
            <strong>Next Steps:</strong><br>
            1. Fix any failing tests<br>
            2. Add service functions to init.php<br>
            3. Test homepage visual<br>
            4. Delete this test file
        </p>
    </div>
</body>
</html>
<?php
/**
 * SITUNEO DIGITAL - Homepage Data Test
 * 
 * Test data integration dari BATCH 1, 2, & 3
 * Cek apakah semua data bisa di-pull dari database
 * 
 * Upload ke root, akses: http://yourdomain.com/test_homepage_data.php
 * DELETE setelah testing selesai!
 */

require_once 'includes/init.php';

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Homepage Data - SITUNEO</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background: #f5f5f5;
        }
        .test-section {
            background: white;
            padding: 25px;
            margin-bottom: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .test-section h2 {
            color: #1E5C99;
            margin: 0 0 15px 0;
            padding-bottom: 10px;
            border-bottom: 2px solid #FFB400;
            font-size: 20px;
        }
        .pass { 
            color: #28a745; 
            font-weight: 600;
            padding: 8px 12px;
            background: #d4edda;
            border-radius: 6px;
            display: inline-block;
            margin: 5px 0;
        }
        .fail { 
            color: #dc3545; 
            font-weight: 600;
            padding: 8px 12px;
            background: #f8d7da;
            border-radius: 6px;
            display: inline-block;
            margin: 5px 0;
        }
        .warning {
            color: #856404;
            background: #fff3cd;
            padding: 12px;
            border-radius: 6px;
            margin: 10px 0;
            border-left: 4px solid #ffc107;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #dee2e6;
        }
        th {
            background: #f8f9fa;
            font-weight: 600;
            color: #495057;
        }
        tr:hover {
            background: #f8f9fa;
        }
        .summary {
            background: linear-gradient(135deg, #1E5C99 0%, #0F3057 100%);
            color: white;
            padding: 40px;
            border-radius: 12px;
            text-align: center;
            margin-bottom: 30px;
        }
        .summary h1 {
            margin: 0 0 10px 0;
            font-size: 32px;
        }
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }
        .stat-item {
            background: rgba(255,255,255,0.15);
            padding: 20px;
            border-radius: 8px;
            backdrop-filter: blur(10px);
        }
        .stat-item h3 {
            margin: 0 0 5px 0;
            font-size: 36px;
            font-weight: 700;
        }
        .stat-item p {
            margin: 0;
            opacity: 0.95;
            font-size: 14px;
        }
        .next-steps {
            text-align: center;
            margin-top: 40px;
            padding: 30px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .next-steps h3 {
            color: #1E5C99;
            margin-bottom: 20px;
        }
        .next-steps ol {
            text-align: left;
            max-width: 600px;
            margin: 0 auto;
            line-height: 2;
        }
        .next-steps ol li {
            padding: 8px 0;
        }
        code {
            background: #f8f9fa;
            padding: 2px 6px;
            border-radius: 4px;
            font-family: 'Courier New', monospace;
            font-size: 13px;
        }
        .link-button {
            display: inline-block;
            margin-top: 20px;
            padding: 12px 30px;
            background: linear-gradient(135deg, #FFD700 0%, #FFB400 100%);
            color: #0F3057;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        .link-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(255, 180, 0, 0.4);
        }
    </style>
</head>
<body>
    <div class="summary">
        <h1>🔧 SITUNEO Homepage Data Test</h1>
        <p>Testing data integration dari BATCH 1, 2, & 3</p>
        <p style="opacity: 0.8; margin-top: 10px; font-size: 14px;">
            Current Date: <?php echo formatDate(date('Y-m-d')); ?>
        </p>
    </div>

    <?php
    $allPass = true;
    $totalTests = 0;
    $passedTests = 0;
    $warnings = [];

    // TEST 1: Database Connection
    echo '<div class="test-section">';
    echo '<h2>1️⃣ Database Connection</h2>';
    $totalTests++;
    
    try {
        $db = Database::getInstance();
        $testQuery = $db->query("SELECT DATABASE() as db_name");
        
        if ($testQuery && $row = $testQuery->fetch_assoc()) {
            echo '<p class="pass">✅ Database Connection: SUCCESS</p>';
            echo '<p><strong>Database:</strong> ' . htmlspecialchars($row['db_name']) . '</p>';
            echo '<p><strong>Host:</strong> ' . DB_HOST . '</p>';
            $passedTests++;
        } else {
            echo '<p class="fail">❌ Database Connection: FAILED</p>';
            $allPass = false;
        }
    } catch (Exception $e) {
        echo '<p class="fail">❌ Database Connection: ERROR</p>';
        echo '<p style="color: #dc3545;">Error: ' . htmlspecialchars($e->getMessage()) . '</p>';
        $allPass = false;
    }
    echo '</div>';

    // TEST 2: Services
    echo '<div class="test-section">';
    echo '<h2>2️⃣ Services Data</h2>';
    $totalTests++;
    
    try {
        $servicesQuery = $db->query("
            SELECT s.*, sc.name as category_name 
            FROM services s 
            LEFT JOIN service_categories sc ON s.category_id = sc.id 
            WHERE s.is_active = 1 
            ORDER BY s.display_order ASC 
            LIMIT 6
        ");
        
        $serviceCount = $servicesQuery ? $servicesQuery->num_rows : 0;
        
        if ($serviceCount > 0) {
            echo '<p class="pass">✅ Services: ' . $serviceCount . ' active services found</p>';
            echo '<table>';
            echo '<tr><th>Service Name</th><th>Category</th><th>Price</th><th>Type</th></tr>';
            
            while ($service = $servicesQuery->fetch_assoc()) {
                echo '<tr>';
                echo '<td>' . htmlspecialchars($service['name']) . '</td>';
                echo '<td>' . htmlspecialchars($service['category_name'] ?? 'N/A') . '</td>';
                echo '<td><strong>' . formatRupiah($service['price']) . '</strong></td>';
                echo '<td>' . ($service['price_type'] == 'one_time' ? 'One-time' : 'Monthly') . '</td>';
                echo '</tr>';
            }
            echo '</table>';
            $passedTests++;
        } else {
            echo '<p class="fail">❌ No services found in database</p>';
            echo '<div class="warning">⚠️ <strong>Action Required:</strong> Run database seeder to add services: <code>/database/seed.php</code></div>';
            $warnings[] = 'Services table is empty - run seeder';
            $allPass = false;
        }
    } catch (Exception $e) {
        echo '<p class="fail">❌ Services Query: ERROR</p>';
        echo '<p style="color: #dc3545;">Error: ' . htmlspecialchars($e->getMessage()) . '</p>';
        $allPass = false;
    }
    echo '</div>';

    // TEST 3: Portfolio
    echo '<div class="test-section">';
    echo '<h2>3️⃣ Portfolio Data</h2>';
    $totalTests++;
    
    try {
        $portfolioQuery = $db->query("
            SELECT * FROM portfolios 
            WHERE is_featured = 1 
            ORDER BY display_order ASC 
            LIMIT 6
        ");
        
        $portfolioCount = $portfolioQuery ? $portfolioQuery->num_rows : 0;
        
        if ($portfolioCount > 0) {
            echo '<p class="pass">✅ Portfolio: ' . $portfolioCount . ' featured projects found</p>';
            echo '<table>';
            echo '<tr><th>Project Name</th><th>Category</th><th>Client</th><th>Status</th></tr>';
            
            while ($item = $portfolioQuery->fetch_assoc()) {
                echo '<tr>';
                echo '<td><strong>' . htmlspecialchars($item['title']) . '</strong></td>';
                echo '<td>' . htmlspecialchars($item['category']) . '</td>';
                echo '<td>' . htmlspecialchars($item['client_name'] ?? 'Confidential') . '</td>';
                echo '<td>' . ucfirst($item['status']) . '</td>';
                echo '</tr>';
            }
            echo '</table>';
            $passedTests++;
        } else {
            echo '<p class="fail">❌ No portfolio items found</p>';
            echo '<div class="warning">⚠️ <strong>Action Required:</strong> Add portfolio items via admin panel or seed database</div>';
            $warnings[] = 'Portfolio table is empty';
            $allPass = false;
        }
    } catch (Exception $e) {
        echo '<p class="fail">❌ Portfolio Query: ERROR</p>';
        echo '<p style="color: #dc3545;">Error: ' . htmlspecialchars($e->getMessage()) . '</p>';
        $allPass = false;
    }
    echo '</div>';

    // TEST 4: Testimonials
    echo '<div class="test-section">';
    echo '<h2>4️⃣ Testimonials Data</h2>';
    $totalTests++;
    
    try {
        $testimonialsQuery = $db->query("
            SELECT * FROM testimonials 
            WHERE is_active = 1 
            ORDER BY display_order ASC 
            LIMIT 6
        ");
        
        $testimonialsCount = $testimonialsQuery ? $testimonialsQuery->num_rows : 0;
        
        if ($testimonialsCount > 0) {
            echo '<p class="pass">✅ Testimonials: ' . $testimonialsCount . ' reviews found</p>';
            echo '<table>';
            echo '<tr><th>Client Name</th><th>Company</th><th>Rating</th><th>Verified</th></tr>';
            
            while ($item = $testimonialsQuery->fetch_assoc()) {
                echo '<tr>';
                echo '<td><strong>' . htmlspecialchars($item['client_name']) . '</strong></td>';
                echo '<td>' . htmlspecialchars($item['company'] ?? 'Individual') . '</td>';
                echo '<td>' . str_repeat('⭐', $item['rating']) . ' <strong>(' . $item['rating'] . '/5)</strong></td>';
                echo '<td>' . ($item['is_verified'] ? '✅ Verified' : '⏳ Pending') . '</td>';
                echo '</tr>';
            }
            echo '</table>';
            $passedTests++;
        } else {
            echo '<p class="fail">❌ No testimonials found</p>';
            echo '<div class="warning">⚠️ <strong>Action Required:</strong> Add testimonials via admin panel</div>';
            $warnings[] = 'Testimonials table is empty';
            $allPass = false;
        }
    } catch (Exception $e) {
        echo '<p class="fail">❌ Testimonials Query: ERROR</p>';
        echo '<p style="color: #dc3545;">Error: ' . htmlspecialchars($e->getMessage()) . '</p>';
        $allPass = false;
    }
    echo '</div>';

    // TEST 5: Blog Posts
    echo '<div class="test-section">';
    echo '<h2>5️⃣ Blog Posts Data</h2>';
    $totalTests++;
    
    try {
        $blogQuery = $db->query("
            SELECT bp.*, bc.name as category_name 
            FROM blog_posts bp 
            LEFT JOIN blog_categories bc ON bp.category_id = bc.id 
            WHERE bp.status = 'published' 
            ORDER BY bp.published_at DESC 
            LIMIT 3
        ");
        
        $blogCount = $blogQuery ? $blogQuery->num_rows : 0;
        
        if ($blogCount > 0) {
            echo '<p class="pass">✅ Blog: ' . $blogCount . ' published posts found</p>';
            echo '<table>';
            echo '<tr><th>Title</th><th>Category</th><th>Author</th><th>Published Date</th></tr>';
            
            while ($post = $blogQuery->fetch_assoc()) {
                echo '<tr>';
                echo '<td><strong>' . htmlspecialchars($post['title']) . '</strong></td>';
                echo '<td>' . htmlspecialchars($post['category_name'] ?? 'Uncategorized') . '</td>';
                echo '<td>' . htmlspecialchars($post['author_name'] ?? 'Admin') . '</td>';
                echo '<td>' . formatDate($post['published_at']) . '</td>';
                echo '</tr>';
            }
            echo '</table>';
            $passedTests++;
        } else {
            echo '<p class="fail">❌ No published blog posts found</p>';
            echo '<div class="warning">⚠️ <strong>Action Required:</strong> Add blog posts via admin panel</div>';
            $warnings[] = 'Blog posts table is empty';
            $allPass = false;
        }
    } catch (Exception $e) {
        echo '<p class="fail">❌ Blog Posts Query: ERROR</p>';
        echo '<p style="color: #dc3545;">Error: ' . htmlspecialchars($e->getMessage()) . '</p>';
        $allPass = false;
    }
    echo '</div>';

    // TEST 6: FAQs
    echo '<div class="test-section">';
    echo '<h2>6️⃣ FAQs Data</h2>';
    $totalTests++;
    
    try {
        $faqsQuery = $db->query("
            SELECT * FROM faqs 
            WHERE is_active = 1 
            ORDER BY display_order ASC 
            LIMIT 8
        ");
        
        $faqCount = $faqsQuery ? $faqsQuery->num_rows : 0;
        
        if ($faqCount > 0) {
            echo '<p class="pass">✅ FAQs: ' . $faqCount . ' questions found</p>';
            echo '<table>';
            echo '<tr><th>Question</th><th>Category</th></tr>';
            
            while ($faq = $faqsQuery->fetch_assoc()) {
                echo '<tr>';
                echo '<td>' . htmlspecialchars(substr($faq['question'], 0, 80)) . '...</td>';
                echo '<td>' . htmlspecialchars($faq['category'] ?? 'General') . '</td>';
                echo '</tr>';
            }
            echo '</table>';
            $passedTests++;
        } else {
            echo '<p class="fail">❌ No FAQs found</p>';
            echo '<div class="warning">⚠️ <strong>Action Required:</strong> Run database seeder: <code>/database/seed.php</code></div>';
            $warnings[] = 'FAQs table is empty - run seeder';
            $allPass = false;
        }
    } catch (Exception $e) {
        echo '<p class="fail">❌ FAQs Query: ERROR</p>';
        echo '<p style="color: #dc3545;">Error: ' . htmlspecialchars($e->getMessage()) . '</p>';
        $allPass = false;
    }
    echo '</div>';

    // TEST 7: Helper Functions
    echo '<div class="test-section">';
    echo '<h2>7️⃣ Helper Functions (BATCH 1)</h2>';
    $totalTests++;
    
    try {
        $tests = [
            'formatRupiah(1500000)' => formatRupiah(1500000),
            'formatRupiahShort(1500000)' => formatRupiahShort(1500000),
            'formatDate("2025-10-30")' => formatDate('2025-10-30'),
            'formatPhone("08123456789")' => formatPhone('08123456789'),
            'whatsappUrl("Test")' => substr(whatsappUrl('Test'), 0, 50) . '...'
        ];
        
        echo '<table>';
        echo '<tr><th width="40%">Function</th><th>Result</th></tr>';
        $allFunctionsWork = true;
        
        foreach ($tests as $func => $result) {
            echo '<tr>';
            echo '<td><code>' . htmlspecialchars($func) . '</code></td>';
            echo '<td><strong>' . htmlspecialchars($result) . '</strong></td>';
            echo '</tr>';
            
            if (empty($result)) {
                $allFunctionsWork = false;
            }
        }
        echo '</table>';
        
        if ($allFunctionsWork) {
            echo '<p class="pass">✅ All helper functions working correctly</p>';
            $passedTests++;
        } else {
            echo '<p class="fail">❌ Some helper functions not working</p>';
            $allPass = false;
        }
    } catch (Exception $e) {
        echo '<p class="fail">❌ Helper Functions: ERROR</p>';
        echo '<p style="color: #dc3545;">Error: ' . htmlspecialchars($e->getMessage()) . '</p>';
        $allPass = false;
    }
    echo '</div>';

    // TEST 8: Constants
    echo '<div class="test-section">';
    echo '<h2>8️⃣ Company Constants (BATCH 1)</h2>';
    $totalTests++;
    
    try {
        $constants = [
            'COMPANY_NAME' => COMPANY_NAME,
            'COMPANY_NIB' => COMPANY_NIB,
            'CONTACT_WHATSAPP' => CONTACT_WHATSAPP,
            'CONTACT_EMAIL_ADMIN' => CONTACT_EMAIL_ADMIN,
            'CONTACT_EMAIL_SUPPORT' => CONTACT_EMAIL_SUPPORT,
        ];
        
        echo '<table>';
        echo '<tr><th>Constant</th><th>Value</th></tr>';
        
        foreach ($constants as $name => $value) {
            echo '<tr>';
            echo '<td><code>' . $name . '</code></td>';
            echo '<td><strong>' . htmlspecialchars($value) . '</strong></td>';
            echo '</tr>';
        }
        echo '</table>';
        
        echo '<p class="pass">✅ All constants defined correctly</p>';
        $passedTests++;
    } catch (Exception $e) {
        echo '<p class="fail">❌ Constants: ERROR</p>';
        echo '<p style="color: #dc3545;">Error: ' . htmlspecialchars($e->getMessage()) . '</p>';
        $allPass = false;
    }
    echo '</div>';

    // FINAL SUMMARY
    $successRate = round(($passedTests / $totalTests) * 100);
    $statusEmoji = $successRate >= 80 ? '🎉' : ($successRate >= 50 ? '⚠️' : '❌');
    
    echo '<div class="test-section summary">';
    echo '<h1>' . $statusEmoji . ' ' . ($allPass ? 'ALL TESTS PASSED!' : 'TESTS COMPLETED') . '</h1>';
    echo '<p style="font-size: 18px; opacity: 0.9;">System Integration Test Results</p>';
    
    echo '<div class="stats">';
    echo '<div class="stat-item">';
    echo '<h3>' . $passedTests . '/' . $totalTests . '</h3>';
    echo '<p>Tests Passed</p>';
    echo '</div>';
    
    echo '<div class="stat-item">';
    echo '<h3>' . $successRate . '%</h3>';
    echo '<p>Success Rate</p>';
    echo '</div>';
    
    echo '<div class="stat-item">';
    echo '<h3>' . count($warnings) . '</h3>';
    echo '<p>Warnings</p>';
    echo '</div>';
    echo '</div>';
    
    if ($allPass && count($warnings) == 0) {
        echo '<p style="margin-top: 30px; font-size: 18px; line-height: 1.6;">';
        echo '✅ <strong>HOMEPAGE IS READY!</strong><br>';
        echo 'Semua data tersedia dan dapat ditampilkan dengan benar.';
        echo '</p>';
        echo '<a href="/" class="link-button">➜ Lihat Homepage</a>';
    } else {
        echo '<p style="margin-top: 30px; font-size: 16px; line-height: 1.6;">';
        if (count($warnings) > 0) {
            echo '⚠️ <strong>' . count($warnings) . ' warning(s) found:</strong><br><br>';
            foreach ($warnings as $warning) {
                echo '• ' . $warning . '<br>';
            }
        } else {
            echo '❌ Some tests failed. Please check the errors above.';
        }
        echo '</p>';
    }
    echo '</div>';
    ?>

    <div class="next-steps">
        <h3>📝 Next Steps</h3>
        <ol>
            <li><strong>Fix BASE_PATH error:</strong> Edit <code>/config/constants.php</code> line 193, add <code>if (!defined('BASE_PATH'))</code></li>
            <li><strong>Seed database:</strong> Run <code>/database/seed.php</code> if any tables are empty</li>
            <li><strong>Test homepage:</strong> Visit <code>/</code> or <code>/index.php</code> in browser</li>
            <li><strong>Test mobile:</strong> Resize browser or test on mobile device</li>
            <li><strong>Test WhatsApp:</strong> Click floating button (bottom-right corner)</li>
            <li><strong>Delete test file:</strong> Remove this file (<code>test_homepage_data.php</code>) after testing</li>
        </ol>
        
        <?php if ($allPass && count($warnings) == 0): ?>
        <p style="margin-top: 30px; padding: 15px; background: #d4edda; color: #155724; border-radius: 8px; border: 1px solid #c3e6cb;">
            <strong>✅ READY FOR PRODUCTION!</strong><br>
            System is fully operational. You can now continue with BATCH 4.2 (remaining pages).
        </p>
        <?php endif; ?>
    </div>

    <div style="text-align: center; margin-top: 30px; padding: 20px; color: #6c757d;">
        <p>🔧 <strong>SITUNEO DIGITAL</strong> - Homepage Data Test v1.0</p>
        <p style="font-size: 13px; margin-top: 5px;">
            Testing BATCH 1 (Config & Functions) + BATCH 2 (Database) + BATCH 3 (CSS & Services)
        </p>
    </div>
</body>
</html>